package com.cg.fms.test;

//import junit.framework.Assert;



import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.IParticipantDao;
import com.cg.fms.dao.ParticipantDaoImpl;
import com.cg.fms.exception.FeedbackException;

public class FeedbackTest {
	
	static IParticipantDao dao = null;
	static FeedbackBean bean = null;
	
	@BeforeClass
	public static void beforeClass() throws FeedbackException
	{
		
		dao = new ParticipantDaoImpl();
		
		bean = new FeedbackBean();
		
	}
	
	@AfterClass
	public static void afterClass()
	{
		dao = null;
		bean=null;
		
	}
	@Before
	public void before()
	{
		System.out.println("Before Test");
		
	}
	
	@After
	public void after()
	{
		System.out.println("After Test");
	}

	@Test
	public void testAddFeedback() throws FeedbackException
	{
				
				bean.setTraining_Code(15);
				bean.setParticipant_id(14);
				bean.setFb_Prs_Comm(5);
				bean.setFb_Clrfy_Dbts(4);
				bean.setFb_Tm(4);
				bean.setFb_Hnd_Out(5);
				bean.setFb_Hw_Sw_Ntwrk(4);
				bean.setComments("good");
				bean.setSuggestions("Include Practical sessions");
				int id = dao.addFeedback(bean);
				System.out.println(id);
				Assert.assertEquals(1,id);
				
		
	}
}
