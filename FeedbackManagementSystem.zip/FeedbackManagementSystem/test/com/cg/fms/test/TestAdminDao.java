package com.cg.fms.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.dao.AdminDaoImpl;
import com.cg.fms.dao.IAdminDao;
import com.cg.fms.exception.FeedbackException;

public class TestAdminDao 
{
	
	static CourseBean cBean=null;
	static IAdminDao dao=null;
	
	@BeforeClass
	public static void beforeClass()
	{
		dao=new AdminDaoImpl();
		cBean=new CourseBean();
	}
	
	@AfterClass
	public static void afterClass()
	{
		dao=null;
		cBean=null;
		
	}
	
	@Before
	public void before()
	{
		System.out.println("before test");
	}
	
	@After
	public void after()
	{
		System.out.println("after test");
	}
	
	@Test
	public void testAddCourse() throws FeedbackException
	{
		cBean.setCourseID(7);
		cBean.setCourseName("devOps");
		cBean.setNoOfDays(30);
		int id=dao.addCourse(cBean);
		Assert.assertEquals( 7, id);
		
		
	}

}
