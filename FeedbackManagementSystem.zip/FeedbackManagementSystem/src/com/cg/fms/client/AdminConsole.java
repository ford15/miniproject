package com.cg.fms.client;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.AdminServiceImpl;
import com.cg.fms.service.IAdminService;

public class AdminConsole {
	public void display() throws FeedbackException {
		IAdminService service = new AdminServiceImpl();
		CourseBean bean = null;
		Scanner sc = new Scanner(System.in);
		while (true) {
			System.out.println("*********************");
			System.out.println("1. Add Course Details");
			System.out.println("2. Delete Course");
			System.out.println("3. Update course");
			System.out.println("4. View All courses");
			System.out.println("5. Faculty Maintenance");
			System.out.println("6. Exit");
			System.out.println("*********************");
			try {
				System.out.println("Enter your choice");
				int choice = sc.nextInt();
				switch (choice) {
				case 1:
					try {
						bean=new CourseBean();
						System.out.println("Enter your CourseName");
						String courseName = sc.next();
						sc.nextLine();
						System.out.println("Enter no of days");
						int noOfDays = sc.nextInt();
						bean.setCourseName(courseName);
						bean.setNoOfDays(noOfDays);
						boolean flag=service.isValidCourse(bean);
						if(flag==true){
						int id = service.addCourse(bean);
						if (id > 0)
						{	
							System.out.println("***********************************");
							System.out.println("Added Successfully Course Id ="+id);
							System.out.println("***********************************");
						}
						}
					}catch (InputMismatchException e) {
						throw new FeedbackException("Invalid Input");
					} catch (FeedbackException e) {
						System.err.println(e.getMessage());
					}
					break;
				case 2:
					try {
						System.out.println("Enter your CourseID");
						int courseId = sc.nextInt();

						bean = service.deleteCourse(courseId);
						if (bean != null) {
							System.out.println(bean.toString());
							System.out.println("*********************");
							System.out.println("Deleted Successfully");
							System.out.println("*********************");
						} else
							System.out.println("CourseID not found.");

					} catch (InputMismatchException e) {
							throw new FeedbackException("Invalid Course Id");
					} catch (FeedbackException e) {
						System.err.println(e.getMessage());
					}
					break;

				case 3:
					
					System.out.println("Enter Course ID");
					int id=sc.nextInt();
					System.out.println("Enter Course Name");
					String name=sc.next();
					System.out.println("Enter No of Days");
					int days=sc.nextInt();
					bean=new CourseBean();
					bean.setCourseID(id);
					bean.setCourseName(name);
					bean.setNoOfDays(days);
					try {
						boolean check=service.isValidCourse(bean);
						if(check)
						{
						boolean flag=service.updateCourse(bean);
						if(flag)
						{
							System.out.println("********************");
							System.out.println("Updated Successfully");
							System.out.println("*********************");
						}
						else
							System.out.println("Invalid Course ID");						
						}
					} catch (InputMismatchException e) {
						throw new FeedbackException("Invalid Course Id");
				}  catch (FeedbackException e) {
							
							System.err.println(e.getMessage());
					}
					break;

				case 4:

					try {
						List<CourseBean> list = service.viewAllCourses();
						if (list.isEmpty()) {
							System.out.println("No Courses found");
						} else {
							System.out.println("****************************************************************");
							for (CourseBean courseBean : list) {
								System.out.println(courseBean.toString());
							}
							System.out.println("*****************************************************************");
						}
					} catch (FeedbackException e) {
						System.err.println(e.getMessage());
					}
					break;

				case 5:

					try {
						System.out.println("Enter faculty ID");
						int facultyId = sc.nextInt();
						System.out.println("Enter the skill");
						String facultySkill = sc.next();

						if (service.addFaculty(facultyId, facultySkill)) {
							System.out.println("************************************");
							System.out.println("Faculty details added successfully.");
							System.out.println("************************************");
						} else {
							System.out.println("Faculty details couldn't be added.");
						}
					} catch (InputMismatchException e) {
						System.err.println("Faculty Id is NOT valid.");
					}
					break;

					
			
				case 6:
					
					System.exit(0);

				default:
					System.out.println("Invalid Choice");
					break;
				}
			} catch (InputMismatchException e) {
				throw new FeedbackException("Invalid choice");
			}

		}

	}
}
