package com.cg.fms.client;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.cg.fms.bean.ParticipantEnrollmentBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.CoordinatorServiceImpl;
import com.cg.fms.service.ICoordinatorService;

public class CoordinatorConsole {

	public void start() throws FeedbackException {

		Scanner sc = new Scanner(System.in);
		ICoordinatorService service = new CoordinatorServiceImpl();
		int option = 0;

		try {
			while (true) {
				System.out.println("===============================");
				System.out.println("1.Add Training Program Details ");
				System.out.println("2.Retrive All");
				System.out.println("3.Update Training Program Details");
				System.out.println("4.Delete Training Program Details");
				System.out.println("5.Enroll Participant");
				System.out.println("6.Exit");
				System.out.println("=================================");
				System.out.println("Select an option:");

				option = sc.nextInt();
				switch (option) {
				case 1:
					try {
						
						System.out.println("Enter Course Code: ");
						int course = sc.nextInt();
						System.out.println("Enter Faculty Code: ");
						int faculty = sc.nextInt();
						sc.nextLine();
						System.out.println("Enter start date(dd-mm-yyyy): ");
						String sdate = sc.nextLine();
						System.out.println("Enter end date(dd-mm-yyyy): ");
						String edate = sc.nextLine();

						TrainingProgramBean bean = new TrainingProgramBean();

						bean.setCourseCode(course);
						bean.setFacultyCode(faculty);

						DateFormat d = new SimpleDateFormat("dd-MM-yy");
						Date startdate = d.parse(sdate);
						bean.setStartDate(startdate);
						Date enddate = d.parse(edate);
						bean.setEndDate(enddate);

						int id = service.addTrainingProgram(bean);

						if (id > 0) {
							System.out
									.println("Training Program added Successfully Training Code ="+id);

						} else
							System.out.println("Training Program failed to add");
					} catch (InputMismatchException e) {
						throw new FeedbackException("Invalid Input");
					} catch (FeedbackException e){
							System.err.println(e.getMessage());
				}
				catch(ParseException e) {
					throw new FeedbackException("Invalid Input");
				}
					break;

				case 2:
					try {
						List<TrainingProgramBean> list = service
								.viewAllTrainingPrograms();
						for (TrainingProgramBean bean1 : list) {
							System.out.println(bean1);
						}
					} catch (FeedbackException e1) {
						System.err.println(e1.getMessage());
					}
					break;

				case 3:

					try {
						System.out.println("Enter the Training Code: ");
						int trainingCode = sc.nextInt();
						sc.nextLine();

						TrainingProgramBean bean = new TrainingProgramBean();
						bean.setTrainingCode(trainingCode);

						System.out.println("Enter the Course code: ");
						int courseCode = sc.nextInt();
						bean.setCourseCode(courseCode);

						System.out.println("Enter the Faculty code: ");
						int facultyCode = sc.nextInt();
						sc.nextLine();
						bean.setFacultyCode(facultyCode);

						System.out.println("Enter the Start date(dd-mm-yyyy): ");
						String sdate = sc.nextLine();

						System.out.println("Enter the End date(dd-mm-yyyy): ");
						String edate = sc.nextLine();

						DateFormat d = new SimpleDateFormat("dd-MM-yy");
						Date startdate = d.parse(sdate);
						bean.setStartDate(startdate);
						Date enddate = d.parse(edate);
						bean.setEndDate(enddate);

						boolean update = service.updateTrainingProgram(bean);
						if (update) {
							System.out.println("Training Details Updated");
						} else {
							System.out.println("Code not found");
						}
					} catch (InputMismatchException e) {
						throw new FeedbackException("Invalid Input");
					} catch (FeedbackException | ParseException e) {

						System.err.println(e.getMessage());
					}
					break;

				case 4:
					try {
						System.out.println("Enter Training code to delete");
						int trainingCode1 = sc.nextInt();

						TrainingProgramBean bean1 = service.deleteTrainingProgram(trainingCode1);
						if(bean1!=null)
						System.out.println(bean1.toString());
						else
						System.out.println("Training Code Not Found");
					} catch (InputMismatchException e) {
						throw new FeedbackException("Invalid Input");
					} catch (FeedbackException e) {

						System.err.println(e.getMessage());
					}
					break;
				case 5:
				
					ParticipantEnrollmentBean bean=new ParticipantEnrollmentBean();
					try {
						System.out.println("Training Code : ");
						bean.setTrainingCode(sc.nextInt());
						System.out.println("Participant ID : ");
						bean.setParticipantId(sc.nextInt());
						
							boolean isEnrolled=service.enrollParticipant(bean);
							if(isEnrolled)
								System.out.println("Participant Enrolled!!");			
							else
								throw new FeedbackException("Participant enrollment is not happend!");											 
					} catch (InputMismatchException e1) {
						throw new FeedbackException("Enter Only Numbers.");
					}catch (FeedbackException e) {
						throw new FeedbackException("Training Code or Participant Id  Not Found!");
					}
					break;
				case 6:

					System.exit(0);
					

				default:
					System.out.println("Enter a valid option[1-4]");
					break;
				}

			}
		}catch (InputMismatchException e) {
			throw new FeedbackException("Invalid choice");
		}
	}
}