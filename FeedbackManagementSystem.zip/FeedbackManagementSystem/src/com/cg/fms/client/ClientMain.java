package com.cg.fms.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserServiceImpl;

public class ClientMain 
{
	
	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		
		try {
		IUserService service=new UserServiceImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your UserId");
		int userId=sc.nextInt();
		System.out.println("Enter your password");
		String password=sc.next();
		
	
		
			String role = service.UserVerification(userId, password);
			if(role==null)
			{
				System.out.println("Invalid ID Password");
			}
			else
			{
			switch(role)
			{
			case "admin":
				AdminConsole admin=new AdminConsole();
				System.out.println("You are logged in as Admin");
				admin.display();
				break;
			case "participant":
				ParticipantConsole par=new ParticipantConsole();
				System.out.println("You are logged in as Participant");
				par.start();
				
				break;
			case "coordinator":
				CoordinatorConsole cord=new CoordinatorConsole();
				System.out.println("You are logged in as Coordinator");
				cord.start();
				break;
			}
		} 
			
		}	
		catch (InputMismatchException e) {
			System.out.println("Invalid User ID");
		}
		catch (FeedbackException e) {
		
			System.out.println(e.getMessage());
		}
		
			
		
	}

}
