package com.cg.fms.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IUserService;
import com.cg.fms.service.UserServiceImpl;

public class ClientMain 
{
	
	public static void main(String[] args) 
	{
		PropertyConfigurator.configure("resources/log4j.properties");
		
		try {
		IUserService service=new UserServiceImpl();
		Scanner sc = new Scanner(System.in);
		System.out.println("******************** Feedback Management System ********************");
		System.out.println("=====================================================================");
		System.out.println("Please Login with your Credentials");
		System.out.println("____________________________________");
		System.out.println("Enter your UserId");
		int userId=sc.nextInt();
		System.out.println("Enter your password");
		String password=sc.next();
		
	
		
			String role = service.UserVerification(userId, password);
			if(role==null)
			{
				System.out.println("Invalid ID Password");
			}
			else
			{
			switch(role)
			{
			case "admin":
				AdminConsole admin=new AdminConsole();
				System.out.println("____________________________");
				System.out.println("You are logged in as Admin");
				System.out.println("____________________________");
				admin.display();
				break;
			case "participant":
				ParticipantConsole par=new ParticipantConsole();
				System.out.println("_________________________________");
				System.out.println("You are logged in as Participant");
				System.out.println("_________________________________");
				par.start();
				
				break;
			case "coordinator":
				CoordinatorConsole cord=new CoordinatorConsole();
				System.out.println("_________________________________");
				System.out.println("You are logged in as Coordinator");
				System.out.println("_________________________________");
				cord.start();
				break;
			}
		} 
			
		}	
		catch (InputMismatchException e) {
			System.out.println("Invalid User ID");
		}
		catch (FeedbackException e) {
		
			System.err.println(e.getMessage());
		}
		
			
		
	}

}
