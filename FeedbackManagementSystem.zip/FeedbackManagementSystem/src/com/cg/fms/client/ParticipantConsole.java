package com.cg.fms.client;

import java.util.InputMismatchException;
import java.util.Scanner;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IParticipantService;
import com.cg.fms.service.ParticipantServiceImpl;

public class ParticipantConsole {

	private Scanner scan;
	private IParticipantService participantService;
	
	
	public void start() {
		System.out.println("Participant Console");
		FeedbackBean bean = new FeedbackBean();
		scan = new Scanner(System.in);
		
		try {
			System.out.println("Enter the training code");
			bean.setTraining_Code(scan.nextInt());
			System.out.println("Enter the participant id");
			bean.setParticipant_id(scan.nextInt());
			System.out.println("Enter feedback prs and comm");
			bean.setFb_Prs_Comm(scan.nextInt());
			System.out.println("Enter score on clarifying doubts");
			bean.setFb_Clrfy_Dbts(scan.nextInt());
			System.out.println("Enter feedback tm score");
			bean.setFb_Tm(scan.nextInt());
			System.out.println("Enter fb handout score");
			bean.setFb_Hnd_Out(scan.nextInt());
			System.out.println("Enter hw/sw score");
			bean.setFb_Hw_Sw_Ntwrk(scan.nextInt());
			System.out.println("Enter your comments");
			scan.next();
			bean.setComments(scan.nextLine());
			
			System.out.println("Enter your suggestions");
			bean.setSuggestions(scan.nextLine());
			
			
				participantService = new ParticipantServiceImpl();
				int isSuccess = participantService.addFeedback(bean);
				
				if(isSuccess > 0)
				{
					System.out.println("Feedback Saved for the participant ID="+bean.getParticipant_id() );
					
				}
				else
				{
					System.err.println("Operation Failed!");
					

					
				}
		} catch (FeedbackException e) {
			System.err.println(e.getMessage());
		}
		 catch (InputMismatchException e) {
				System.err.println("Invalid entry!!! Enter data in proper format");
			}
		
		
	}


}
