package com.cg.fms.dao;

public interface IQueryMapper 
{
	//Admin
	
	public final String User="select Role from EMPLOYEE_MASTER WHERE Employee_ID=? AND Password=?";
	
	public final String AddCourse="insert into COURSE_MASTER values(seq_course_id.nextval,?,?)";
	
	public final String DeleteCourse="delete from COURSE_MASTER where course_Id=?";
	
	public final String SelectCourse="select course_ID,course_Name,no_Of_Days from COURSE_MASTER where course_Id=?";

	public final String AddFaculty="insert into FACULTY_SKILL values(?,?)";
	
	public static final String UPDATE_COURSE="update course_master set course_name=?,no_Of_Days=? where course_Id=?";
	
	public static final String SELECT_COURSES="select course_Id,course_name,no_Of_Days from course_master";
	
	//public static final String VIEW_REPORT="select t.training_code,avg(fb_prs_comm),avg(fb_clrfy_dbts),avg(fb_tm),avg(fb_hnd_out),avg(fb_hw_sw_ntwrk) from training_program t,feedback_master f where t.training_code=f.training_code and to_char(start_date,'MON')='?' group by t.training_code";
	
	//Coordinator
	
	
	public static final String INSERT_QUERY = "insert into training_program(training_code,course_code,faculty_code,start_date,end_date) values (seq_training_code.nextval,?,?,?,?)";
	
	public static final String SELECT_ALL_QUERY = "select training_code,course_code,faculty_code,start_date,end_date from training_program";
	
	public static final String DELETE_QUERY = "delete from training_program where training_code=?";
	
	public static final String VIEW_BY_ID = "select training_code,course_code,faculty_code,start_date,end_date from training_program where training_code=?";
	
	public static final String UPDATE_QUERY = " UPDATE training_program SET course_code=?,faculty_code=?,start_date=?,end_date=? WHERE training_code=?";
	
	public static final String GET_USER="SELECT employee_id,employeename,password,role FROM employee_master WHERE employee_id=? and password=?";
	
	public static final String PARTICIPANT_ENROLLMENT="INSERT INTO training_enrollment(training_code,participant_id) VALUES(?,?)";
	
	//Participant
	
	public static final String GIVE_FEEDBACK="INSERT INTO feedback_master(training_Code,participant_id,fb_Prs_Comm,fb_Clrfy_Dbts,fb_Tm,fb_Hnd_Out,fb_Hw_Sw_Ntwrk,comments,suggestions)VALUES(?,?,?,?,?,?,?,?,?)";

	
}
