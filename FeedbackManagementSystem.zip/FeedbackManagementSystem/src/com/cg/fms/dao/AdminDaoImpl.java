package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBConnection;

public class AdminDaoImpl implements IAdminDao
{
	Connection con;
	CourseBean bean=null;
	static Logger log = Logger.getLogger(AdminDaoImpl.class);
	
	@Override
	public int addCourse(CourseBean bean)  throws FeedbackException
	{
		
		int course = 0;
		try {
			con=DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement ps=con.prepareStatement(IQueryMapper.AddCourse);
			
			ps.setInt(1, bean.getCourseID());
			ps.setString(2, bean.getCourseName());
			ps.setInt(3, bean.getNoOfDays());
			
			int count=ps.executeUpdate();
			
			if(count>0)
			{	
				log.info("fetching course Id");
				course=bean.getCourseID();
			
			}else
			{
				log.error("Course Information could not be added");
				throw new FeedbackException("Course Information could not be added");
			}
		
		} catch (SQLException e) {
			log.error("Course Information could not be added sql error");
			throw new FeedbackException("Course Information could not be added");
		}
		
					
		return course;
	}

	@Override
	public CourseBean deleteCourse(int courseId) throws FeedbackException 
	{
		
		try {
			con=DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement ps=con.prepareStatement(IQueryMapper.SelectCourse);			
			ps.setInt(1, courseId);
			ResultSet rs=ps.executeQuery();
			if(rs.next())
			{
				log.info("fetching course details");
				bean=new CourseBean();
				bean.setCourseID(rs.getInt("course_ID"));
				bean.setCourseName(rs.getString("course_Name"));
				bean.setNoOfDays(rs.getInt("no_Of_Days"));
				PreparedStatement ps1=con.prepareStatement(IQueryMapper.DeleteCourse);
				ps1.setInt(1, courseId);				
				int count=ps1.executeUpdate();
				log.info("deleted successfully");
				if(count<0){
					
					log.error("Course Id not found");
					throw new FeedbackException("Course Id not found");

				}
								
			}			
	
			con.close();
		}  catch (SQLException e) {
			log.error("Course Information could not be deleted sql error");
			throw new FeedbackException("unable to delete");
		}
		return bean;
	}

	@Override
	public boolean addFaculty(int facultyId, String facultySkill) throws FeedbackException{
		boolean flag = false;
		try {
			con=DBConnection.getConnection();
			log.debug("Connection Established");
			PreparedStatement ps=con.prepareStatement(IQueryMapper.AddFaculty);
			ps.setInt(1,facultyId);
			ps.setString(2,facultySkill);
			int count=ps.executeUpdate();
			
			if(count>0)
			{
				 flag = true;
				 log.info("faculty skills added successfully");
			}
				 else{
					  log.info("unable to add faculty skills");
					 throw new FeedbackException("Faculty details could not be added");
				 }
			con.close();	
			   
		}  catch (SQLException e) {
			
			log.error("cant added to the database sql error");
			throw new FeedbackException("The entered Faculty ID can't be added to the database.");
		}
		
		
		return flag;
	
	}

	@Override
	public List<CourseBean> viewAllCourses() throws FeedbackException {

		List<CourseBean> list = new ArrayList<CourseBean>();
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		try {
			PreparedStatement pstmt = con.prepareStatement(IQueryMapper.SELECT_COURSES);
			ResultSet rs = pstmt.executeQuery();
			while (rs.next()) {
				log.info("fetching course details successfull");
				CourseBean bean = new CourseBean();
				bean.setCourseID(rs.getInt("course_id"));
				bean.setCourseName(rs.getString("course_name"));
				bean.setNoOfDays(rs.getInt("no_Of_Days"));
				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			log.error("unable to fetch records SQL error");
			throw new FeedbackException("Unable to fetch records");
		}
		return list;
	}

	@Override
	public boolean updateCourse(CourseBean bean) throws FeedbackException {

		boolean flag = false;
		Connection con = DBConnection.getConnection();
		log.debug("Connection Established");
		try {
			PreparedStatement pstmt = con.prepareStatement(IQueryMapper.UPDATE_COURSE);
			pstmt.setString(1, bean.getCourseName());
			pstmt.setInt(2, bean.getNoOfDays());
			pstmt.setInt(3, bean.getCourseID());
			int count = pstmt.executeUpdate();
			if (count > 0) {
				log.info("updated course details successfully");
				flag = true;
			}
			con.close();
		} catch (SQLException e) {
			log.error("unable to update SQL error");
			throw new FeedbackException("Unable to Update");
		}

		return flag;
	}

}
