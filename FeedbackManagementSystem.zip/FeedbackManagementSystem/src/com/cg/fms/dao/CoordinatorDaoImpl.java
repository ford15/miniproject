package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.cg.fms.bean.ParticipantEnrollmentBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBConnection;



public class CoordinatorDaoImpl implements ICoordinatorDao {
	private Logger log = Logger.getLogger("CoordinatorDaoImpl.class");

	public CoordinatorDaoImpl() {
		PropertyConfigurator.configure("resources/log4j.properties");
	}

	@Override
	public List<TrainingProgramBean> viewAllTrainingPrograms()
			throws FeedbackException {

		List<TrainingProgramBean> list = new ArrayList<TrainingProgramBean>();
		log.debug("VIEW COORDINATOR CALLED ");
		try {
			Connection con = DBConnection.getConnection();
			log.debug("CONNECTION SUCCESS");

			String qry = IQueryMapper.SELECT_ALL_QUERY;
			PreparedStatement pstmt = con.prepareStatement(qry);
			ResultSet rst = pstmt.executeQuery();
			while (rst.next()) {

				TrainingProgramBean bean = new TrainingProgramBean();

				bean.setTrainingCode(rst.getInt("training_code"));
				bean.setCourseCode(rst.getInt("course_code"));
				bean.setFacultyCode(rst.getInt("faculty_code"));
				bean.setStartDate(rst.getDate("start_date"));
				bean.setEndDate(rst.getDate("end_date"));

				list.add(bean);
			}
			con.close();
		} catch (SQLException e) {
			log.error(e);
			throw new FeedbackException("Exception in view all coordinator"+ e.getMessage());

		}
		log.debug("VIEW COORDINATOR COMPLETED");
		return list;

	}

	@Override
	public int addTrainingProgram(TrainingProgramBean bean)
			throws FeedbackException {
		int trainingId = 0;
		log.debug("ADD COORDINATOR CALLED ");

		try {
			Connection con = DBConnection.getConnection();
			log.debug("CONNECTION SUCCESS");

			String qry = IQueryMapper.INSERT_QUERY;
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, bean.getCourseCode());
			pstmt.setInt(2, bean.getFacultyCode());
			Date startdate = bean.getStartDate();
			Date enddate = bean.getEndDate();
			java.sql.Date sdate = new java.sql.Date(startdate.getTime());
			java.sql.Date edate = new java.sql.Date(enddate.getTime());
			pstmt.setDate(3, sdate);
			pstmt.setDate(4, edate);
			int count = pstmt.executeUpdate();

			if (count > 0) {
				
				log.info("Insertion Success ");
				PreparedStatement pstmt1=con.prepareStatement("select seq_training_code.currval from dual");
				ResultSet rs=pstmt1.executeQuery();
				rs.next();
				trainingId=rs.getInt(1);
				
			} else {
				log.debug("Insertion Failed");
				throw new FeedbackException("Insertion failed");
			}
			con.close();

		} catch (SQLException e) {
			throw new FeedbackException("Course Code or Faculty Code not found");
		}
		log.debug("ADD COORDINATOR COMPLETED");
		
		return trainingId;
	}

	@Override
	public TrainingProgramBean deleteTrainingProgram(int trainingCode) throws FeedbackException  {
		TrainingProgramBean bean = null;
		log.debug("DELETE COORDINATOR CALLED ");
		try {

			Connection con = DBConnection.getConnection();
			String qry = IQueryMapper.VIEW_BY_ID;
			PreparedStatement pstmt = con.prepareStatement(qry);
			pstmt.setInt(1, trainingCode);
			ResultSet rst = pstmt.executeQuery();

			if (rst.next()) {
				bean=new TrainingProgramBean();
				bean.setTrainingCode(rst.getInt("training_code"));
				bean.setCourseCode(rst.getInt("course_code"));
				bean.setFacultyCode(rst.getInt("faculty_code"));
				bean.setStartDate(rst.getDate("start_date"));
				bean.setEndDate(rst.getDate("end_date"));
				qry = IQueryMapper.DELETE_QUERY;
				pstmt = con.prepareStatement(qry);
				pstmt.setInt(1, trainingCode);
				int count = 0;
				count = pstmt.executeUpdate();

				if (count > 0) {
					System.out.println("Details Deleted");

				} else
					throw new FeedbackException("Details not Deleted");
			}

		} catch (FeedbackException e) {
			log.error(e);
			throw new FeedbackException("ExceptionOccur" + e.getMessage());
		} catch (SQLException e) {
			log.error(e);
			throw new FeedbackException("SQL Exception" + e.getMessage());
		}
		log.debug("DELETE COORDINATOR COMPLETED");
		return bean;
	}

	
	@Override
	public boolean updateTrainingProgram(TrainingProgramBean bean)
			throws FeedbackException {

		boolean flag = false;
		log.debug("UPDATE COORDINATOR CALLED ");
		try {
			Connection connection = DBConnection.getConnection();
			

			PreparedStatement pstmt = connection
					.prepareStatement(IQueryMapper.UPDATE_QUERY);

			pstmt.setInt(1, bean.getCourseCode());
			pstmt.setInt(2, bean.getFacultyCode());
			Date startdate = bean.getStartDate();
			Date enddate = bean.getEndDate();
			java.sql.Date sdate = new java.sql.Date(startdate.getTime());
			java.sql.Date edate = new java.sql.Date(enddate.getTime());
			pstmt.setDate(3, sdate);
			pstmt.setDate(4, edate);
			pstmt.setInt(5, bean.getTrainingCode());
			int count = pstmt.executeUpdate();

			if (count != 0)
				flag = true;
		} catch (SQLException e) {
			log.error(e);
			throw new FeedbackException("Training Code, Course Code or Faculty code not found");
		} 
		log.debug("UPDATE COORDINATOR COMPLETED");
		return flag;
	}



	@Override
	public boolean enrollParticipant(ParticipantEnrollmentBean bean) throws FeedbackException {
		
		boolean isDone = false;
		if (bean != null) {

			try (Connection con = DBConnection.getConnection();) {
				log.info("Connection Established");
				try (PreparedStatement st = con
						.prepareStatement(IQueryMapper.PARTICIPANT_ENROLLMENT);) {

					//con.setAutoCommit(false);
					st.setInt(1, bean.getTrainingCode());
					st.setInt(2, bean.getParticipantId());

					int count = st.executeUpdate();

			
						if (count > 0) {
							isDone = true;
							log.info("Participant Enrolled");
						}
						else
						{
							log.info("Unable to Enroll Participant");
							isDone=false;
						}
				} catch (SQLException e) {
					log.error(e);
					throw new FeedbackException("Unable To Enroll Participant"+e.getMessage());
				}
			} catch (SQLException e) {
				log.error(e);
				throw new FeedbackException("Unable To Enroll Participant"+e.getMessage());
			}
		}
		return isDone;
	}

	
}


