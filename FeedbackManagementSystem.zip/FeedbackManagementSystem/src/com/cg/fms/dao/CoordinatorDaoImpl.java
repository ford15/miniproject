package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;

@Repository
@Transactional
public class CoordinatorDaoImpl implements ICoordinatorDao{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public int addTrainingProgram(TrainingProgramBean bean) throws FeedbackException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public List<TrainingProgramBean> viewAllTrainingPrograms() throws FeedbackException {
		
		TypedQuery<TrainingProgramBean> qry=em.createQuery("SELECT bean From TrainingProgramBean bean", TrainingProgramBean.class);
		List<TrainingProgramBean> list=qry.getResultList();
		
		return list;
	}

	@Override
	public void updateTrainingProgram(TrainingProgramBean bean) throws FeedbackException {

			try {
				em.merge(bean);
			} catch (Exception e) {
					
					throw new FeedbackException("Unable to Update");
			}
	}



	@Override
	public boolean enrollParticipant(ParticipantEnrollmentBean bean) throws FeedbackException {
		
		try {
			em.persist(bean);
		} catch (Exception e) {
			throw new FeedbackException("Unable to Enroll.");
		}
		
		return true;
	}

	@Override
	public TrainingProgramBean getTrainingPrograms(TrainingProgramBean tpbean) throws FeedbackException {

		try {
			tpbean=em.find(TrainingProgramBean.class, tpbean.getTrainingCode());
		} catch (Exception e) {
			throw new FeedbackException("ID not Found");
		}
		return tpbean;
	}

	
	@Override
	public void deleteTrainingProgram(TrainingProgramBean tpbean) throws FeedbackException {
			System.out.println("dao"+tpbean.getTrainingCode());
			em.remove(tpbean);
		
	}

	
}
