package com.cg.fms.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.util.DBConnection;



public class ParticipantDaoImpl implements IParticipantDao {
	
	private Logger classLogger;
	

	public ParticipantDaoImpl() throws FeedbackException {
		classLogger = Logger.getLogger(ParticipantDaoImpl.class);
	}
	
	
	@Override
	public int addFeedback(FeedbackBean bean) throws FeedbackException {

		int result1=0;
		
			try {
				Connection con = DBConnection.getConnection();
				PreparedStatement st = con.prepareStatement(IQueryMapper.GIVE_FEEDBACK);
								
				st.setInt(1, bean.getTraining_Code());
				st.setInt(2, bean.getParticipant_id());
				st.setInt(3, bean.getFb_Prs_Comm());
				st.setInt(4, bean.getFb_Clrfy_Dbts());
				st.setInt(5, bean.getFb_Tm());
				st.setInt(6, bean.getFb_Hnd_Out());
				st.setInt(7, bean.getFb_Hw_Sw_Ntwrk());
				st.setString(8, bean.getComments());
				st.setString(9, bean.getSuggestions());
				
				result1 = st.executeUpdate();
				if(result1<1)
				{
					classLogger.info("Failed to add");
					throw new FeedbackException("unable to add");
				}
				System.out.println("Data inserted");
				classLogger.info("Feedback added succesfully");
				//System.out.println(result1);
				con.close();
				
			} catch (SQLException e) {
				classLogger.error(e);
				System.err.println("Could not add feedback data :" + e.getMessage());
			}
			
		return result1;	
		
	}

}
