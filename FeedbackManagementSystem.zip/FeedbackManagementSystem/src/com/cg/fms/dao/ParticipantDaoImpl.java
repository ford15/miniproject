package com.cg.fms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.exception.FeedbackException;

@Repository
@Transactional
public class ParticipantDaoImpl implements IParticipantDao
{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public int addFeedback(FeedbackBean bean) throws FeedbackException {
		
		em.persist(bean);
		return bean.getParticipant_id();
	}

}
