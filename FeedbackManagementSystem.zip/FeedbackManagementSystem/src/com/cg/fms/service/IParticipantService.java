package com.cg.fms.service;


import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
public interface IParticipantService {
	
	public int addFeedback(FeedbackBean bean)throws FeedbackException;
	public boolean isValidFeedback(FeedbackBean bean) throws FeedbackException;

}
