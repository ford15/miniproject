package com.cg.fms.service;


import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
public interface IParticipantService {
	
	public int addFeedback(FeedbackBean bean)throws FeedbackException;
	

}
