package com.cg.fms.service;


import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.IParticipantDao;
import com.cg.fms.dao.ParticipantDaoImpl;
import com.cg.fms.exception.FeedbackException;


public class ParticipantServiceImpl implements IParticipantService{
	
	private IParticipantDao participantdao = null;
	
	public ParticipantServiceImpl() throws FeedbackException
	{
		participantdao = new ParticipantDaoImpl();
	}

	@Override
	public int addFeedback(FeedbackBean bean) throws FeedbackException {
		
		int result;
		if (isValidFeedback(bean)){
		result = participantdao.addFeedback(bean);
		}
		else{
			throw new FeedbackException("Enter a correct Feedback");
		}
		return result;
	}

	@Override
	public boolean isValidFeedback(FeedbackBean bean) throws FeedbackException {
		
		
		if(bean != null)
		{
			if (!validateTrainingCode(bean.getTraining_Code())) {
				throw new FeedbackException("Training code should contain only numbers");
			}
			
			if (!validateParticipantId(bean.getParticipant_id())) {
				throw new FeedbackException("Participant Id should contain only numbers");
			}
			if (!validateFbPrsCon(bean.getFb_Prs_Comm())) {
				throw new FeedbackException("Score of pros and cons should contain only digits from 1-5");
			}
			if (!validateFbClrfyDbts(bean.getFb_Clrfy_Dbts())) {
				throw new FeedbackException("Feedback score of clarifying doubts should contain only digit from 1-5");
			}
			if (!validateFbTm(bean.getFb_Tm())) {
				throw new FeedbackException("Feedback Tm should contain only digits from 1-5");
			}
			if (!validateFbHndOut(bean.getFb_Hnd_Out())) {
				throw new FeedbackException("Feedback score of hand outs should contain only digit from 1-5");
			}
			if (!validateFbHwSwNtwrk(bean.getFb_Hw_Sw_Ntwrk())) {
				throw new FeedbackException("Feedback score of software/hardware should contain only digit from 1-5");
			}
		}
		return true;
	}
	
	public boolean validateTrainingCode(int training_Code) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[0-9]+");
		Matcher matcher = pattern.matcher(String.valueOf(training_Code));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}

	public boolean validateParticipantId(int participant_id) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[0-9]{1}[0-9]{1,}");
		Matcher matcher = pattern.matcher(String.valueOf(participant_id));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
	
	public boolean validateFbPrsCon (int fb_Prs_Comm) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[1-5]");
		Matcher matcher = pattern.matcher(String.valueOf(fb_Prs_Comm));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
	
	public boolean validateFbClrfyDbts(int fb_Clrfy_Dbts) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[1-5]");
		Matcher matcher = pattern.matcher(String.valueOf(fb_Clrfy_Dbts));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
	
	public boolean validateFbTm(int fb_Tm) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[1-5]");
		Matcher matcher = pattern.matcher(String.valueOf(fb_Tm));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
	
	public boolean validateFbHndOut(int fb_Hnd_Out) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[1-5]");
		Matcher matcher = pattern.matcher(String.valueOf(fb_Hnd_Out));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
	
	public boolean validateFbHwSwNtwrk(int fb_Hw_Sw_Ntwrk) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[1-5]");
		Matcher matcher = pattern.matcher(String.valueOf(fb_Hw_Sw_Ntwrk));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
}
