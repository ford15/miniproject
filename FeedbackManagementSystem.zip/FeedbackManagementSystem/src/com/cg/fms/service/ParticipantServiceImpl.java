package com.cg.fms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.dao.IParticipantDao;
import com.cg.fms.exception.FeedbackException;

@Service
public class ParticipantServiceImpl implements IParticipantService
{
	@Autowired
	IParticipantDao dao;

	@Override
	public int addFeedback(FeedbackBean bean) throws FeedbackException {
	
		return dao.addFeedback(bean);
	}

}
