package com.cg.fms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.dao.ICoordinatorDao;
import com.cg.fms.exception.FeedbackException;

@Service
public class CoordinatorServiceImpl implements ICoordinatorService{

	@Autowired
	ICoordinatorDao dao;
	
	
	@Override
	public boolean addParticipant(ParticipantEnrollmentBean pebean) throws FeedbackException {
		
		return dao.enrollParticipant(pebean);
	}


	@Override
	public List<TrainingProgramBean> viewAllTrainingPrograms() throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.viewAllTrainingPrograms();
	}


	@Override
	public TrainingProgramBean getTrainingPrograms(TrainingProgramBean tpbean) throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getTrainingPrograms(tpbean);
	}


	@Override
	public void deleteTrainingProgram(TrainingProgramBean tpbean) throws FeedbackException {
		// TODO Auto-generated method stub
		System.out.println("service"+tpbean.getTrainingCode());
		dao.deleteTrainingProgram(tpbean);
	}


	@Override
	public void updateTrainingProgram(TrainingProgramBean bean) throws FeedbackException {
		
		dao.updateTrainingProgram(bean);
	}
		
}
