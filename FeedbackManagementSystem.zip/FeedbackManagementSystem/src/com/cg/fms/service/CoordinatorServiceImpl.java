package com.cg.fms.service;

import java.sql.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.dao.ICoordinatorDao;
import com.cg.fms.exception.FeedbackException;

@Service
public class CoordinatorServiceImpl implements ICoordinatorService{

	@Autowired
	ICoordinatorDao dao;
	
	
	@Override
	public boolean addParticipant(ParticipantEnrollmentBean pebean) throws FeedbackException {
		
		return dao.enrollParticipant(pebean);
	}


	@Override
	public List<TrainingProgramBean> viewAllTrainingPrograms() throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.viewAllTrainingPrograms();
	}


	@Override
	public TrainingProgramBean getTrainingPrograms(TrainingProgramBean tpbean) throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.getTrainingPrograms(tpbean);
	}




	@Override
	public void updateTrainingProgram(TrainingProgramBean bean) throws FeedbackException {
		
		dao.updateTrainingProgram(bean);
	}


	@Override
	public int addTrainingProgram(TrainingProgramBean bean)throws FeedbackException {
		
		int result;
		if(isValidFeedback(bean))
		{
			result = dao.addTrainingProgram(bean);
		}
		else{
			throw new FeedbackException("Enter the correct Details ");
		}
		return result;
	}


	@Override
	public TrainingProgramBean deleteTrainingProgram(TrainingProgramBean bean)
			throws FeedbackException {
		
		return dao.deleteTrainingProgram(bean);
	}


	@Override
	public List<CourseBean> viewAllCourses() throws FeedbackException {
		
		return dao.viewAllCourses();
	}


	@Override
	public List<UserBean> viewAllFaculty() throws FeedbackException {
		return dao.viewAllFaculty();
	}


	@Override
	public boolean isValidFeedback(TrainingProgramBean bean)throws FeedbackException {
		if(bean !=null)
		{
			if (!validateStartEndDate(bean.getEndDate(),bean.getStartDate())) {
				throw new FeedbackException("End date should be greater than Start date");
			}
		}
		return true;
	}
	public boolean validateStartEndDate(Date date,Date date2)
	{

		boolean flag = false;
		if(!date.before(date2))
		{
			flag=true;
		}
		
		
		return(flag);
	}
		
}
