package com.cg.fms.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.fms.bean.ParticipantEnrollmentBean;
import com.cg.fms.bean.TrainingProgramBean;
import com.cg.fms.dao.CoordinatorDaoImpl;
import com.cg.fms.dao.ICoordinatorDao;
import com.cg.fms.exception.FeedbackException;



public class CoordinatorServiceImpl implements ICoordinatorService{

	
	ICoordinatorDao dao = new CoordinatorDaoImpl();

	@Override
	public List<TrainingProgramBean> viewAllTrainingPrograms()
			throws FeedbackException {
		return dao.viewAllTrainingPrograms();
	}

	@Override
	public boolean updateTrainingProgram(TrainingProgramBean bean)
			throws FeedbackException {
		boolean flag=false;
		if (validateTrainingCode1(bean.getTrainingCode())) {
			if (validateCourseCode(bean.getCourseCode())) {
				if (validateFacultyCode(bean.getFacultyCode())) {
					flag = dao.updateTrainingProgram(bean);
				} else
					throw new FeedbackException("Enter valid Faculty Code");
			} else
				throw new FeedbackException("Enter valid Course Code");
		} else
			throw new FeedbackException("Enter valid Training Code");
		
		return flag;

	}

	@Override
	public int addTrainingProgram(TrainingProgramBean bean) throws FeedbackException {
		int id = 0;
		
			if (validateCourseCode(bean.getCourseCode())) {
				if (validateFacultyCode(bean.getFacultyCode())) {
					id = dao.addTrainingProgram(bean);
				} else
					throw new FeedbackException("Enter valid Faculty Code");
			} else
				throw new FeedbackException("Enter valid Course Code");
	

		return id;

	}

	private boolean validateFacultyCode(int facultyCode) {
		boolean b = false;

		Pattern pattern = Pattern.compile("[0-9]{1,6}");
		Matcher matcher = pattern.matcher(String.valueOf(facultyCode));
		if (matcher.matches()) {
			b = true;
		}

		return b;

	}

	private boolean validateCourseCode(int courseCode) {
		boolean b = false;

		Pattern pattern = Pattern.compile("[0-9]{1,4}");
		Matcher matcher = pattern.matcher(String.valueOf(courseCode));
		if (matcher.matches()) {
			b = true;
		}

		return b;

	}

	private boolean validateTrainingCode1(int trainingCode) {
		boolean b = false;

		Pattern pattern = Pattern.compile("[0-9]{1,3}");
		Matcher matcher = pattern.matcher(String.valueOf(trainingCode));
		if (matcher.matches()) {
			b = true;
		}

		return b;

	}

	@Override
	public TrainingProgramBean deleteTrainingProgram(int trainingCode)
			throws FeedbackException {

		return dao.deleteTrainingProgram(trainingCode);
	}
	
	public CoordinatorServiceImpl() {
		dao=new CoordinatorDaoImpl();
	}
	
	@Override
	public boolean enrollParticipant(ParticipantEnrollmentBean bean)
			throws FeedbackException {
		return dao.enrollParticipant(bean);
	
		 
	}
	@Override
	public boolean isValid(ParticipantEnrollmentBean bean1)
	{
		
		if(!validateTrainingCode1(bean1.getTrainingCode()))
		System.out.println("Trainig Id must be digit");
		
		if(!validateParticipantId(bean1.getParticipantId()))
		System.out.println("Participant id must be digit");
		
		return true;
	}


	public boolean validateParticipantId(int pid)
	{
		boolean flag=false;
		Pattern pattern=Pattern.compile("[1-9]*");
		Matcher matcher=pattern.matcher(String.valueOf(pid));
		if(matcher.matches())
		{	
			flag=true;
		}
		else
		{
			flag=false;
		}
			return flag;
	}
}
