package com.cg.fms.service;

import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.log4j.Logger;

import com.cg.fms.bean.CourseBean;
import com.cg.fms.bean.FeedbackBean;
import com.cg.fms.dao.AdminDaoImpl;
import com.cg.fms.dao.IAdminDao;
import com.cg.fms.exception.FeedbackException;

public class AdminServiceImpl implements IAdminService
{
	
	
	IAdminDao dao=new AdminDaoImpl();
	static Logger log = Logger.getLogger(AdminDaoImpl.class);
	
	@Override
	public int addCourse(CourseBean bean) throws FeedbackException {

		log.info("addCourse() function called successfully");
		int course=dao.addCourse(bean);
		return course;
	}
	
	@Override
	public CourseBean deleteCourse(int courseId) throws FeedbackException {
		log.info("deleteCourse() function called successfully");
		return dao.deleteCourse(courseId);
	}
	
	@Override
	public boolean addFaculty(int facultyId, String facultySkill) throws FeedbackException{
		log.info("addFaculty() function called successfully");
		return dao.addFaculty(facultyId, facultySkill);
	}
	
	
	@Override
	public List<CourseBean> viewAllCourses() throws FeedbackException {
		
		log.info("viewAllCourses() function called successfully");
		return dao.viewAllCourses();
	}

	@Override
	public boolean updateCourse(CourseBean bean) throws FeedbackException {
		
		boolean flag=false;
		log.info("updateCourse() function called successfully"); 
		flag=isValidCourse(bean);
		if(flag)
		flag=dao.updateCourse(bean);
		return flag;
	}
	
	
	
	public boolean validatecourseName(String string) {
		
		boolean flag = false;
		Pattern pattern = Pattern.compile("[.a-zA-Z]+[ a-zA-Z#+]*");
		Matcher matcher = pattern.matcher(String.valueOf(string));
		if(matcher.matches())
		{
			flag=true;
		}
		else
			flag=false;
		
		return(flag);
	}
	


	@Override
	public boolean isValidCourse(CourseBean bean) throws FeedbackException {

		if (!validatecourseName(bean.getCourseName())) {
			throw new FeedbackException("Course Name should contain only alphabets");
		}
		return true;
	}

	/*@Override
	public List<FeedbackBean> viewReport(String MON) throws FeedbackException
	{
		return dao.viewReport(MON);
	}
	*/
}
