package com.cg.fms.service;


import java.util.List;

import com.cg.fms.exception.FeedbackException;
import com.cg.fms.bean.ParticipantEnrollmentBean;
import com.cg.fms.bean.TrainingProgramBean;

public interface ICoordinatorService {

	public int addTrainingProgram(TrainingProgramBean bean) throws FeedbackException;

	public List<TrainingProgramBean> viewAllTrainingPrograms() throws FeedbackException;

	public boolean updateTrainingProgram(TrainingProgramBean bean) throws FeedbackException;

	public TrainingProgramBean deleteTrainingProgram(int trainingCode) throws FeedbackException;
	
	public boolean enrollParticipant(ParticipantEnrollmentBean bean) throws FeedbackException;
	
	public boolean isValid(ParticipantEnrollmentBean bean)throws FeedbackException;
}
