package com.cg.fms.bean;

public class FacultySkillBean 
{
	private int facutlyId;
	private String skillSet;
	public int getFacutlyId() {
		return facutlyId;
	}
	public void setFacutlyId(int facutlyId) {
		this.facutlyId = facutlyId;
	}
	public String getSkillSet() {
		return skillSet;
	}
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	
	

}
