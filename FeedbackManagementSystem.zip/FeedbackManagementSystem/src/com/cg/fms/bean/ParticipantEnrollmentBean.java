package com.cg.fms.bean;

public class ParticipantEnrollmentBean {

	private int trainingCode;
	private int participantId;
	public ParticipantEnrollmentBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ParticipantEnrollmentBean(int trainingCode, int participantId) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
	}
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	
	
}
