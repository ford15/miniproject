package com.cg.fms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;

@Entity
@Table(name="training_enrollment")
public class ParticipantEnrollmentBean {

	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int enrollmentNo;
	@Column(name="training_code")
	private int trainingCode;
	@Column(name="participant_id")
	@NotNull
	@Min(value=1000,message=" enter 4 digit valid ID")
	@Max(value=9999,message=" enter 4 digit valid ID")
	private int participantId;
	public ParticipantEnrollmentBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public ParticipantEnrollmentBean(int trainingCode, int participantId) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
	}
	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getParticipantId() {
		return participantId;
	}
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	
	
}
