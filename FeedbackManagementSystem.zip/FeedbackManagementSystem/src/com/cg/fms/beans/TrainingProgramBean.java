package com.cg.fms.beans;

import java.util.Date;



public class TrainingProgramBean {

	private int trainingCode;
	private int courseCode;
	private int facultyCode;
	private Date startDate;
	private Date endDate;
	
	public TrainingProgramBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	public TrainingProgramBean(int trainingCode, int courseCode,
			int facultyCode, Date startDate, Date endDate) {
		super();
		this.trainingCode = trainingCode;
		this.courseCode = courseCode;
		this.facultyCode = facultyCode;
		this.startDate = startDate;
		this.endDate = endDate;
	}

	public int getTrainingCode() {
		return trainingCode;
	}
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	public int getCourseCode() {
		return courseCode;
	}
	public void setCourseCode(int courseCode) {
		this.courseCode = courseCode;
	}
	public int getFacultyCode() {
		return facultyCode;
	}
	public void setFacultyCode(int facultyCode) {
		this.facultyCode = facultyCode;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}

	@Override
	public String toString() {
		return "TrainingProgramBean [trainingCode=" + trainingCode
				+ ", courseCode=" + courseCode + ", facultyCode=" + facultyCode
				+ ", startDate=" + startDate + ", endDate=" + endDate + "]";
	}
	
	
	
}
