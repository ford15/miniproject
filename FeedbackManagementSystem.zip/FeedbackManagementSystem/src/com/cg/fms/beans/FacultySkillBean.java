package com.cg.fms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="faculty_skill")
public class FacultySkillBean 
{
	@Id
	private int skillCode;
	@Column(name="faculty_id")
	private int facutlyId;
	@Column(name="skill_set")
	private String skillSet;
	
	public int getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(int skillCode) {
		this.skillCode = skillCode;
	}

	
	public int getFacutlyId() {
		return facutlyId;
	}
	
	public void setFacutlyId(int facutlyId) {
		this.facutlyId = facutlyId;
	}
	
	public String getSkillSet() {
		return skillSet;
	}
	
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	
	

}
