package com.cg.fms.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.service.IParticipantService;

@Controller
@RequestMapping("*.par")
public class ParticipantController 
{
	@Autowired
	IParticipantService service;
	@RequestMapping("/showAddFeedback")
	public ModelAndView showFeedback(){
		
		FeedbackBean fbean=new FeedbackBean();
		return new ModelAndView("getFeedback","fbean",fbean);
	}
	
	@RequestMapping("/addFeedback")
	public ModelAndView addFeedback(@ModelAttribute("fbean") FeedbackBean fbean)
	{
		return new ModelAndView("showFeedback","fbean",fbean);
	}

}
