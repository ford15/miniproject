package com.cg.fms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.ParticipantEnrollmentBean;

@Controller
@RequestMapping("*.coo")
public class CoordinatorController {

	@RequestMapping("/showPartEnroll")
	public ModelAndView showPartEnroll()
	{
		ParticipantEnrollmentBean pebean=new ParticipantEnrollmentBean();
		return new ModelAndView("enrollParticipant","pebean",pebean);
	}
}
