package com.cg.fms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.ICoordinatorService;

@Controller
@RequestMapping("*.coo")
public class CoordinatorController {

	@Autowired
	ICoordinatorService service;
	
	
	@RequestMapping("/showTrainprgm")
	public ModelAndView showTrainPrgmPage()
	{
		return new ModelAndView("trainingProgramMenu");		
	}
	
	@RequestMapping("/showDeleteProgram")
	public ModelAndView showDeletePage()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv= new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	@RequestMapping("/showUpdateProgram")
	public ModelAndView showUpdatePage()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	
	
	@RequestMapping("/UpdateTrainingPrgm")
	public ModelAndView UpadteProgram(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{

		ModelAndView mv;
		if(!result.hasErrors())
		{
		try {
				service.updateTrainingProgram(tpbean);
				mv=new ModelAndView("updateTrainingProgram","message","Updated Successfully");
				mv.addObject("isFirst", "true");
		} catch (FeedbackException e) {
				
			mv=new ModelAndView("updateTrainingProgram","message",e.getMessage());
		}
		}
		else
			mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);		
		
		return mv;
	}
	
	@RequestMapping("/getTrainingPrgm")
	public ModelAndView getProgram(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				tpbean=service.getTrainingPrograms(tpbean);
				mv= new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
			} catch (FeedbackException e) {

				mv= new ModelAndView("deleteTrainingProgram","message",e.getMessage());
			}
		}
		else
		{
			mv= new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
		}
		return mv;		
	}
	
	@RequestMapping("/getTrainingPrgmDetails")
	public ModelAndView getProgramdDetails(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				tpbean=service.getTrainingPrograms(tpbean);
				mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);
			} catch (FeedbackException e) {

				mv= new ModelAndView("updateTrainingProgram","message",e.getMessage());
			}
		}
		else
		{
			mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);
		}
		return mv;		
	}
	
	
	@RequestMapping("/showPartEnroll")
	public ModelAndView showPartEnroll()
	{
		ParticipantEnrollmentBean pebean=new ParticipantEnrollmentBean();
		
		ModelAndView mv;
		List<TrainingProgramBean> list=null;
		
		try {
			list = service.viewAllTrainingPrograms();
			List<Integer> codeList=new ArrayList<>();
			for(TrainingProgramBean tpbean:list)
			{
				codeList.add(tpbean.getTrainingCode());
			}
			mv= new ModelAndView("enrollParticipant","pebean",pebean);
			mv.addObject("codeList", codeList);
			
		} catch (FeedbackException e) {
			
			mv= new ModelAndView("enrollParticipant","pebean",pebean);
		}
		
		return mv;
		
	}
	
	@RequestMapping("/enrollParticipant")
	public ModelAndView enrollParticipant(@ModelAttribute("pebean") @Valid ParticipantEnrollmentBean pebean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				service.addParticipant(pebean);
				mv=new ModelAndView("enrollParticipant","message","Enrolled Successfully.");
				
			} catch (FeedbackException e) {
				mv=new ModelAndView("enrollParticipant","message",e.getMessage());
				e.printStackTrace();
			}
		}
		else
		{
			try {
				mv=new ModelAndView("enrollParticipant","pebean",pebean);
				List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
				List<Integer> codeList=new ArrayList<>();
				for(TrainingProgramBean tpbean:list)
				{
					codeList.add(tpbean.getTrainingCode());
				}
				mv.addObject("codList", codeList);
			} catch (FeedbackException e) {
				mv=new ModelAndView("enrollParticipant","message",e.getMessage());
			}
		}	
		return mv;
	}
}
