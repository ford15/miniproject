package com.cg.fms.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.FacultySkillBean;

@Controller
@RequestMapping("*.admin")
public class AdminController {

		@RequestMapping("/showFacultySkill")
		public ModelAndView showFacultySkillPage()
		{
			FacultySkillBean fsbean=new FacultySkillBean();
			return new ModelAndView("addFacultySkill","fsbean",fsbean);
		}
		
		@RequestMapping("/addSkillSet")
		public ModelAndView addSkillSet()
		{
			return new ModelAndView("addFacultySkill","message","added");
		}
}
