package com.cg.fms.controller;

import java.util.List;

import javax.enterprise.inject.Model;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.FacultySkillBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IAdminService;

@Controller
@RequestMapping("*.admin")
public class AdminController {

		@Autowired
		IAdminService service;
	
		@RequestMapping("/showFacultySkill")
		public ModelAndView showFacultySkillPage()
		{
			FacultySkillBean fsbean=new FacultySkillBean();
			return new ModelAndView("addFacultySkill","fsbean",fsbean);
		}
		
		@RequestMapping("/addSkillSet")
		public ModelAndView addSkillSet()
		{
			return new ModelAndView("addFacultySkill","message","added");
		}
		
		@RequestMapping("/showCourseMenu")
		public ModelAndView showCourseMenu()
		{			
			return new ModelAndView("showCourseMenu");
		}

//**********************************************Add course***********************************************************************		
		@RequestMapping("/showAddCourse")
		public ModelAndView showAddCourse()
		{
			CourseBean cbean =new CourseBean();
			return new ModelAndView("addCourse","cbean",cbean);
		}
		
		
		@RequestMapping("/addCourse")
		public ModelAndView addCourse(@ModelAttribute("cbean") @Valid CourseBean cbean,BindingResult result)
		{
			ModelAndView mv;
			if(!result.hasErrors())
			{
				try {
					int courseId=service.addCourse(cbean);
					mv=new ModelAndView("showCourseMenu","courseId",courseId);
					mv.addObject("message", "Added Successfully");
				} catch (FeedbackException e) {
					
					mv=new ModelAndView("addCourse","message",e.getMessage());
				}
			}
			else
			{
				mv=new ModelAndView("addCourse","cbean",cbean);
			}
			return mv;
		}
		
//**********************************************view all courses***********************************************************************			
			
		@RequestMapping("/showViewCourses")
		public ModelAndView getCourses()
		{
			ModelAndView mv;
			List<CourseBean> list;
			try {
				
				list = service.viewAllCourses();
				if(!list.isEmpty())
				mv=new ModelAndView("viewAllCourses","list",list);
				else
					mv=new ModelAndView("viewAllCourses","message","No Courese Details Found");
			} 
			catch (FeedbackException e) {
				
				mv=new ModelAndView("viewAllCourses","message",e.getMessage());
			}
			return mv;
		}

		//**********************************************delete courses***********************************************************************
		
		@RequestMapping("/showDeleteCourse")
		public ModelAndView showDeleteCourse()
		{
			CourseBean cbean =new CourseBean();
			ModelAndView mv= new ModelAndView("deleteCourse","cbean",cbean);
			mv.addObject("isFirst", "true");
			return mv;
		}
		
		@RequestMapping("/deleteCourse")
		public ModelAndView deleteCourse(@ModelAttribute("cbean") CourseBean cbean)
		{
			ModelAndView mv;
			try {
				cbean=service.deleteCourse(cbean.getCourseID());
				System.out.println(cbean.getCourseName());
				mv=new ModelAndView("deleteCourse","cbean",cbean);
				mv.addObject("message", "Deleted Successfully");
			} catch (FeedbackException e) {

				mv=new ModelAndView("deleteCourse","message",e.getMessage());
			}
			
			return mv;
		}
		//**************************************************update courses**************************************************************************
		
		@RequestMapping("/showUpdateCourse")
		public ModelAndView showUpdateCourse()
		{
			CourseBean cbean =new CourseBean();
			ModelAndView mv= new ModelAndView("updateCourse","cbean",cbean);
			mv.addObject("isFirst", "true");
			return mv;
			
		}
		@RequestMapping("/updateCourse")
		public ModelAndView updateCourse(@ModelAttribute("cbean") CourseBean cbean)
		{
			ModelAndView mv;
			try {
				boolean flag;
				
				flag=service.updateCourse(cbean);
				mv=new ModelAndView("updateCourse","cbean",cbean);
				mv.addObject("message", "Updated Successfully");
			} catch (FeedbackException e) {
				mv=new ModelAndView("updateCourse","message",e.getMessage());
			}
			return mv;
		}
}
