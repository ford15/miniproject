package com.cg.fms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IUserService;

@Controller
@RequestMapping("*.usr")
public class UserController 
{
	@Autowired
	IUserService service;
	
		@RequestMapping("/showHomePage")
		public ModelAndView showLogin()
		{
			UserBean user=new UserBean();
			return new ModelAndView("springhtml","user",user); 
		}

		@RequestMapping("/verifyUser")
		public ModelAndView verifyUser(@ModelAttribute("user") @Valid UserBean user,BindingResult result)
		{
			ModelAndView mv;
			if(!result.hasErrors())
			{
				try {
					
					user=service.UserVerification(user);
					mv=new ModelAndView("homepage","user",user);
					
				} 
				
				catch (FeedbackException e) 
				{
					mv=new ModelAndView("springhtml","message",e.getMessage());
				}
				
			}
			else
			{
				mv=new ModelAndView("springhtml","user",user);
			}
			
			return  mv; 
		}
}
