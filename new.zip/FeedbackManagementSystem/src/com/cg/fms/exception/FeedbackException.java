package com.cg.fms.exception;

public class FeedbackException extends Exception
{

	public FeedbackException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	

}
