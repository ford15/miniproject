package com.cg.fms.dao;

import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;

public interface IUserDao 
{
	
	public UserBean UserVerification(UserBean user) throws FeedbackException;

}
