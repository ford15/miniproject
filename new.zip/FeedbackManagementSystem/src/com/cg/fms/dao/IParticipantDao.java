package com.cg.fms.dao;

import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.exception.FeedbackException;


public interface IParticipantDao {

		public int addFeedback(FeedbackBean bean)throws FeedbackException;
}
