package com.cg.fms.service;

import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;

public interface IUserService 
{
	
	public UserBean UserVerification(UserBean user) throws FeedbackException;

}
