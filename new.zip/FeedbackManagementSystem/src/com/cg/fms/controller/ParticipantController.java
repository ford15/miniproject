package com.cg.fms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IParticipantService;

@Controller
@RequestMapping("*.par")
public class ParticipantController {

	@Autowired
	IParticipantService service;
	
	public ParticipantController() {
		
		System.out.println("Controller Called");
	}
	
	@RequestMapping("/showAddFeedback")
	public ModelAndView showFeedback()
	{
		FeedbackBean fbean=new FeedbackBean();
		return new ModelAndView("participant","fbean",fbean);
	}
	
	@RequestMapping("/addFeedback")
	public ModelAndView addFeedback(@ModelAttribute("fbean") @Valid FeedbackBean fbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				int pId=service.addFeedback(fbean);
				mv=new ModelAndView("feedbacksuccess","message","Thanks For Your Feedback.");
				mv.addObject("pId", pId);
			} catch (FeedbackException e) {
				mv=new ModelAndView("participant","message",e.getMessage());			
				}
		}
		else
			mv=new ModelAndView("participant","fbean",fbean);
		
		return mv;
	}
	
}
