package com.cg.fms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;


@Entity
@Table(name="course_master")
@SequenceGenerator(name="course_id_gen",initialValue=8002,allocationSize=100)
public class CourseBean 
{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE,generator="course_id_gen")
	@Column(name="course_id")
	private int courseID;
	@Column(name="course_name")
	@Pattern(regexp="[a-zA-Z.#+]+[ a-zA-Z.#+]*",message="Enter Valid Course Name" )
	private String courseName;
	@Column(name="no_of_days")
	@Min(value=1 ,message="Enter Valid Course Duration")
	private int noOfDays;
	
	public int getCourseID() {
		return courseID;
	}
	public void setCourseID(int courseID) {
		this.courseID = courseID;
	}
	public String getCourseName() {
		return courseName;
	}
	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}
	public int getNoOfDays() {
		return noOfDays;
	}
	public void setNoOfDays(int noOfDays) {
		this.noOfDays = noOfDays;
	}
	public CourseBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	public CourseBean(int courseID, String courseName, int noOfDays) {
		super();
		this.courseID = courseID;
		this.courseName = courseName;
		this.noOfDays = noOfDays;
		
		
	}
	
	
	@Override
	public String toString() {
		return "CourseBean [courseID=" + courseID + ", courseName="
				+ courseName + ", noOfDays=" + noOfDays + "]";
	}

}
