package com.cg.fms.controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IUserService;

@Controller
@RequestMapping("*.usr")
@SessionAttributes("session_user")
public class UserController 
{
	@Autowired
	IUserService service;
	
		@RequestMapping("/showHomePage")
		public ModelAndView showLogin()
		{
			UserBean user=new UserBean();
			return new ModelAndView("welcome","user",user); 
		}
		@RequestMapping("/about")
		public ModelAndView about()
		{
			
			return new ModelAndView("aboutus"); 
		}
		@RequestMapping("/home")
		public ModelAndView home()
		{
			UserBean user=new UserBean();
			return new ModelAndView("welcome","user",user); 
		}
		
		/*@RequestMapping("/logout")
		public ModelAndView logout()
		{
			UserBean user=new UserBean();
			return new ModelAndView("logout","user",user); 
		}
*/
		@RequestMapping("/verifyUser")
		public ModelAndView verifyUser(@ModelAttribute("user") @Valid UserBean user,BindingResult result)
		{
			ModelAndView mv = null;
			if(!result.hasErrors())
			{
				try {
					
					user=service.UserVerification(user);
					if(user.getRole().equals("admin"))
					{
					mv=new ModelAndView("adminhome","user",user);
					mv.addObject("session_user", user.getEmpId());
					}
					else if(user.getRole().equals("coordinator"))
					{
					mv=new ModelAndView("coordinatorhome","user",user);
					mv.addObject("session_user", user.getEmpId());
					}
					else if(user.getRole().equals("participant"))
					{
					mv=new ModelAndView("participanthome","user",user);
					mv.addObject("session_user", user.getEmpId());
					}
					
				} 
				
				catch (FeedbackException e) 
				{
					mv=new ModelAndView("welcome","message",e.getMessage());
				}
				
			}
			else
			{
				mv=new ModelAndView("welcome","user",user);
			}
			
			return  mv; 
		}
}
