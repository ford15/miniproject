package com.cg.fms.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.FacultySkillBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IAdminService;

@Controller
@RequestMapping("*.admin")
public class AdminController {

		@Autowired
		IAdminService service;
		
		@RequestMapping("/showCourseMenu")
		public ModelAndView showCourseMenu()
		{	
			
			return new ModelAndView("coursehome");
		}
	
		//*******************************************Add FacultySkills******************************************************//
		
		@RequestMapping("/showFacultySkill")
		public ModelAndView showFacultySkillPage()
		{
			FacultySkillBean fsbean=new FacultySkillBean();
			return new ModelAndView("AddSkills","fsbean",fsbean);
		}
		@RequestMapping("/aboutadmin")
		public ModelAndView about()
		{
			
			return new ModelAndView("aboutus"); 
		}
		@RequestMapping("/homeadmin")
		public ModelAndView home()
		{
			
			return new ModelAndView("adminhome"); 
		}
		@RequestMapping("/logout")
		public ModelAndView logout()
		{
			UserBean user=new UserBean();
			return new ModelAndView("logout","user",user); 
		}

		
		@RequestMapping("/addSkillSet")
		public ModelAndView addSkillSet(@ModelAttribute("fsbean") FacultySkillBean fsbean,BindingResult result)
		{
			ModelAndView mv;
			if(!result.hasErrors())
			{
				try {
					int facultyId=service.addFaculty(fsbean);
					mv=new ModelAndView("AddSkills","facultyId",facultyId);
					mv.addObject("message", "Added Successfully");
				} catch (FeedbackException e) {
					
					mv=new ModelAndView("AddSkills","message",e.getMessage());
				}
			}
			else
			{
				mv=new ModelAndView("AddSkills","fsbean",fsbean);
			}
			return mv;
		}
		
	

//**********************************************Add course***********************************************************************		
		@RequestMapping("/showAddCourse")
		public ModelAndView showAddCourse()
		{
			CourseBean cbean =new CourseBean();
			return new ModelAndView("addcourse","cbean",cbean);
		}
		
		
		@RequestMapping("/addCourse")
		public ModelAndView addCourse(@ModelAttribute("cbean") @Valid CourseBean cbean,BindingResult result)
		{
			ModelAndView mv;
			if(!result.hasErrors())
			{
				try {
					int courseId=service.addCourse(cbean);
					mv=new ModelAndView("showCourseMenu","courseId",courseId);
					mv.addObject("message", "Added Successfully");
				} catch (FeedbackException e) {
					
					mv=new ModelAndView("addcourse","message",e.getMessage());
				}
			}
			else
			{
				mv=new ModelAndView("addcourse","cbean",cbean);
			}
			return mv;
		}
		
//**********************************************view all courses***********************************************************************			
			
		@RequestMapping("/showViewCourses")
		public ModelAndView getCourses()
		{
			ModelAndView mv;
			List<CourseBean> list;
			try {
				
				list = service.viewAllCourses();
				if(!list.isEmpty())
				mv=new ModelAndView("viewallcourse","list",list);
				else
					mv=new ModelAndView("viewallcourse","message","No Course Details Found");
			} 
			catch (FeedbackException e) {
				
				mv=new ModelAndView("viewallcourse","message",e.getMessage());
			}
			return mv;
		}

		//**********************************************delete courses***********************************************************************
		
		@RequestMapping("/showDeleteCourse")
		public ModelAndView showDeleteCourse()
		{
			CourseBean cbean =new CourseBean();
			ModelAndView mv= new ModelAndView("deletecourses","cbean",cbean);
			mv.addObject("isFirst", "true");
			return mv;
		}
		
		@RequestMapping("/deleteCourse")
		public ModelAndView deleteCourse(@ModelAttribute("cbean") CourseBean cbean)
		{
			ModelAndView mv;
			try {
				cbean=service.deleteCourse(cbean.getCourseID());
				mv=new ModelAndView("deletecourses","cbean",cbean);
				mv.addObject("message", "Deleted Successfully");
			} catch (FeedbackException e) {
				
				mv=new ModelAndView("deletecourses","message",e.getMessage());
				mv.addObject("isFirst", "true");
			}
			
			return mv;
		}
		//**************************************************update courses**************************************************************************
		
		@RequestMapping("/showUpdateCourse")
		public ModelAndView showUpdateCourse()
		{
			CourseBean cbean =new CourseBean();
			ModelAndView mv= new ModelAndView("updateCourses","cbean",cbean);
			mv.addObject("isFirst", "true");
			
			return mv;
			
		}
		@RequestMapping("/updateCourse")
		public ModelAndView updateCourse(@ModelAttribute("cbean") @Valid CourseBean cbean,BindingResult result)
		{
			ModelAndView mv;
			if(!result.hasErrors())
			{
			try {				
				service.updateCourse(cbean);
				mv=new ModelAndView("updateCourses","cbean",cbean);
				mv.addObject("message", "Updated Successfully");
				mv.addObject("isFirst", "true");
			
				
			} catch (FeedbackException e) {
				mv=new ModelAndView("updateCourses","message",e.getMessage());
				mv.addObject("isFirst", "true");
			}
			}
			else
			{
				mv=new ModelAndView("updateCourses","cbean",cbean);
			}
			return mv;
		}
		
		@RequestMapping("/getCourseDetails")
		public ModelAndView getCourseDetails(@ModelAttribute("cbean")  CourseBean cbean,BindingResult result)
		{
			ModelAndView mv;
			if(!result.hasErrors())
			{
			try {
				cbean=service.getCourse(cbean);
				 mv=new ModelAndView("updateCourses","cbean",cbean);
			} catch (FeedbackException e) {
				mv=new ModelAndView("updateCourses","message","ID not found");
				mv.addObject("isFirst", "true");
			}
			}
			else
			{
				 mv=new ModelAndView("updateCourses","cbean",cbean);
			}
			return mv;		
		}
	
		
	
}
