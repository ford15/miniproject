package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.FacultySkillBean;
import com.cg.fms.exception.FeedbackException;

public interface IAdminDao {


	public int addCourse(CourseBean bean) throws FeedbackException;

	public CourseBean deleteCourse(int courseId) throws FeedbackException;

	public int addFaculty(FacultySkillBean fbean) throws FeedbackException;
	
	public List<CourseBean> viewAllCourses() throws FeedbackException;
	
	public void updateCourse(CourseBean bean) throws FeedbackException;
	
	public CourseBean getCourse(CourseBean bean) throws FeedbackException;
	
}
