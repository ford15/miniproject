package com.cg.fms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;

@Repository
@Transactional
public class UserDaoImpl implements IUserDao
{
	@PersistenceContext
	EntityManager em;
	
	@Override
	public UserBean UserVerification(UserBean user) throws FeedbackException 
	{
		try {
			
			TypedQuery<UserBean> qry=em.createQuery("FROM UserBean WHERE empId=? AND password=?", UserBean.class);
			qry.setParameter(1, user.getEmpId());
			qry.setParameter(2, user.getPassword());
			 user=qry.getSingleResult();
			 
		} catch (Exception e) {

			throw new FeedbackException("Invalid Credentials");	
			
		}
		
		return user;
	}


	
}
