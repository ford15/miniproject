package com.cg.fms.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.TypedQuery;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.FacultySkillBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;

@Repository
@Transactional
public class AdminDaoImpl implements IAdminDao{

	@PersistenceContext
	EntityManager em;
	
	@Override
	public int addCourse(CourseBean bean) throws FeedbackException {
		
		
		if(bean!=null)
		{
			em.persist(bean);
			
		} 
		else
		{
				throw new FeedbackException("Add Unsuccessfull");
		}
		return bean.getCourseID();
	}

	@Override
	public List<CourseBean> viewAllCourses() throws FeedbackException {

		List<CourseBean> list;
		try {
			TypedQuery<CourseBean> qry=em.createQuery("SELECT c FROM CourseBean c", CourseBean.class);
			list = qry.getResultList();
		} catch (Exception e) {

				throw new FeedbackException("Unable to fetch details");
		}		
		return list;
	}

	@Override
	public CourseBean deleteCourse(int courseId) throws FeedbackException {
		
			CourseBean bean,bean1;
	
			bean=em.find(CourseBean.class, courseId);
			bean1=bean;
			if(bean!=null){
			em.remove(bean1);		
			}
			else {
			throw new FeedbackException("ID not Found");
		}
		return bean;
	}

	@Override
	public void updateCourse(CourseBean bean) throws FeedbackException {
			
			if(bean!=null) {
				System.out.println("dao"+bean.getCourseID());
				em.merge(bean);
			} else {
				throw new FeedbackException("Unable to Update");		
				}
	
	}

	@Override
	public CourseBean getCourse(CourseBean bean) throws FeedbackException {
		
		
			bean=em.find(CourseBean.class,bean.getCourseID());
			if(bean==null)
			{
				throw new FeedbackException("ID not Found");
			}
		
		return bean;
	}

	@Override
	public int addFaculty(FacultySkillBean fbean) throws FeedbackException {

		UserBean bean=em.find(UserBean.class, fbean.getFacutlyId());
		if(bean!=null)
		{
			em.persist(fbean);
		}
		else
			throw new FeedbackException("Faculty ID Not Found.");
		
		return fbean.getFacutlyId();
	}

	
	

	
}
