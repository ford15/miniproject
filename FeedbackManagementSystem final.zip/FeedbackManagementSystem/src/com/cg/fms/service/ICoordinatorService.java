package com.cg.fms.service;

import java.util.List;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;

public interface ICoordinatorService {

	public boolean addParticipant(ParticipantEnrollmentBean pebean) throws FeedbackException;
	public int addTrainingProgram(TrainingProgramBean bean) throws FeedbackException;
	public List<TrainingProgramBean> viewAllTrainingPrograms() throws FeedbackException;
	public TrainingProgramBean getTrainingPrograms(TrainingProgramBean tpbean) throws FeedbackException;
	public TrainingProgramBean deleteTrainingProgram(TrainingProgramBean bean) throws FeedbackException;
	public void updateTrainingProgram(TrainingProgramBean bean) throws FeedbackException;
	public List<CourseBean> viewAllCourses() throws FeedbackException;
	public List<UserBean> viewAllFaculty() throws FeedbackException;
	public boolean isValidFeedback(TrainingProgramBean bean) throws FeedbackException;
}
