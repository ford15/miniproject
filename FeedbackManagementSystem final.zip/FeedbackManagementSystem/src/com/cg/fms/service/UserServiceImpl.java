package com.cg.fms.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.beans.UserBean;
import com.cg.fms.dao.IUserDao;
import com.cg.fms.exception.FeedbackException;

@Service
public class UserServiceImpl implements IUserService
{
	@Autowired
	IUserDao dao;

	@Override
	public UserBean UserVerification(UserBean user) throws FeedbackException {
		// TODO Auto-generated method stub
		return dao.UserVerification(user);
	}




}
