package com.cg.fms.test;

import junit.framework.Assert;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.fms.dao.IUserDao;
import com.cg.fms.dao.UserDaoImpl;
import com.cg.fms.exception.FeedbackException;

public class TestUserDao {

	static IUserDao dao;
	
	@BeforeClass
	public static void beforeClass()
	{
		dao=new UserDaoImpl();
	}
	
	@AfterClass
	public static void afterClass()
	{
		dao=null;		
	}
	
	@Before
	public void before()
	{
		System.out.println("before test");
	}
	
	@After
	public void after()
	{
		System.out.println("after test");
	}
	
	/*@Test
	public void testLogin() throws FeedbackException
	{
		//String role=dao.UserVerification(14291, "system@123");
		Assert.assertEquals("admin", role);
		String role1=dao.UserVerification(14293, "system@123");
		Assert.assertEquals("coordinator", role1);
		String role2=dao.UserVerification(14294, "system@123");
		Assert.assertEquals("participant",role2);
	}*/
	
}
