package com.cg.fms.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

@Entity
@Table(name="feedback_master")
public class FeedbackBean {
	
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Id
	private int feedback_no;
	@NotNull
	private int training_Code;
	@NotNull
	private int participant_id;
	@Min(value=1,message="enter rating in 1 to 5")
	@Max(value=5,message="enter rating in 1 to 5")
	private int fb_Prs_Comm;
	@Min(value=1,message="enter rating in 1 to 5")
	@Max(value=5,message="enter rating in 1 to 5")
	private int fb_Clrfy_Dbts;
	@Min(value=1,message="enter rating in 1 to 5")
	@Max(value=5,message="enter rating in 1 to 5")
	private int fb_Tm;
	@Min(value=1,message="enter rating in 1 to 5")
	@Max(value=5,message="enter rating in 1 to 5")
	private int fb_Hnd_Out;
	@Min(value=1,message="enter rating in 1 to 5")
	@Max(value=5,message="enter rating in 1 to 5")
	private int fb_Hw_Sw_Ntwrk;
	@Pattern(regexp="[a-zA-Z]+[ a-zA-Z]*",message="enter only alphabets")
	private String comments;
	@Pattern(regexp="[a-zA-Z]+[ a-zA-Z]*",message="enter only alphabets")
	private String suggestions;
	
	
	public int getTraining_Code() {
		return training_Code;
	}
	public void setTraining_Code(int training_Code) {
		this.training_Code = training_Code;
		
	}
	public int getParticipant_id() {
		return participant_id;
	}
	public void setParticipant_id(int participant_id) {
		this.participant_id = participant_id;
	}
	public int getFb_Prs_Comm() {
		return fb_Prs_Comm;
	}
	public void setFb_Prs_Comm(int fb_Prs_Comm) {
		this.fb_Prs_Comm = fb_Prs_Comm;
	}
	public int getFb_Clrfy_Dbts() {
		return fb_Clrfy_Dbts;
	}
	public void setFb_Clrfy_Dbts(int fb_Clrfy_Dbts) {
		this.fb_Clrfy_Dbts = fb_Clrfy_Dbts;
	}
	public int getFb_Tm() {
		return fb_Tm;
	}
	public void setFb_Tm(int fb_Tm) {
		this.fb_Tm = fb_Tm;
	}
	public int getFb_Hnd_Out() {
		return fb_Hnd_Out;
	}
	public void setFb_Hnd_Out(int fb_Hnd_Out) {
		this.fb_Hnd_Out = fb_Hnd_Out;
	}
	public int getFb_Hw_Sw_Ntwrk() {
		return fb_Hw_Sw_Ntwrk;
	}
	public void setFb_Hw_Sw_Ntwrk(int fb_Hw_Sw_Ntwrk) {
		this.fb_Hw_Sw_Ntwrk = fb_Hw_Sw_Ntwrk;
	}
	public String getComments() {
		return comments;
	}
	public void setComments(String comments) {
		this.comments = comments;
	}
	public String getSuggestions() {
		return suggestions;
	}
	public void setSuggestions(String suggestions) {
		this.suggestions = suggestions;
	}

	
	
}
