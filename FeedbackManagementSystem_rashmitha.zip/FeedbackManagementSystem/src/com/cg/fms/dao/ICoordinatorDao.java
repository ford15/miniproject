package com.cg.fms.dao;

import java.util.List;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;



public interface ICoordinatorDao {

	public int addTrainingProgram(TrainingProgramBean bean) throws FeedbackException;

	public List<TrainingProgramBean> viewAllTrainingPrograms() throws FeedbackException;
	
	public TrainingProgramBean getTrainingPrograms(TrainingProgramBean tpbean) throws FeedbackException;

	public void updateTrainingProgram(TrainingProgramBean bean) throws FeedbackException;

	public void deleteTrainingProgram(TrainingProgramBean bean) throws FeedbackException;
	
	public boolean enrollParticipant(ParticipantEnrollmentBean bean) throws FeedbackException;
	
	public List<CourseBean> viewAllCourses() throws FeedbackException;
	
	public List<UserBean> viewAllFaculty() throws FeedbackException;
}
