package com.cg.fms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;





import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.IAdminService;
import com.cg.fms.service.ICoordinatorService;

@Controller
@RequestMapping("*.coo")
public class CoordinatorController {

	@Autowired
	ICoordinatorService service;
	
	
	@RequestMapping("/showTrainprgm")
	public ModelAndView showTrainPrgmPage()
	{
		return new ModelAndView("trainingProgramMenu");		
	}
	
	@RequestMapping("/showDeleteProgram")
	public ModelAndView showDeletePage()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv= new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	
	
	
	
	@RequestMapping("/getTrainingPrgm")
	public ModelAndView getProgram(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				tpbean=service.getTrainingPrograms(tpbean);
				mv= new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
			} catch (FeedbackException e) {

				mv= new ModelAndView("deleteTrainingProgram","message",e.getMessage());
			}
		}
		else
		{
			mv= new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
		}
		return mv;		
	}

	@RequestMapping("/deleteTrainingPrgm")
	public ModelAndView deleteTrainingPrgm(@ModelAttribute("tpbean") TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				//TrainingProgramBean tpbean1=tbean;
				service.deleteTrainingProgram(tpbean);
				mv=new ModelAndView("deleteTraining","message","Training program deleted successfully");
				
			} catch (FeedbackException e) {
				mv=new ModelAndView("deleteTraining","message",e.getMessage());			
				}
			return mv;
		}
		else
		{
				mv=new ModelAndView("deleteTrainingProgram","tpbean",tpbean);
				
		
		return mv;
	}
	
	
	}
	
	@RequestMapping("/showUpdateProgram")
	public ModelAndView showUpdatePage()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	
	
	@RequestMapping("/UpdateTrainingPrgm")
	public ModelAndView UpadteProgram(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{

		ModelAndView mv;
		if(!result.hasErrors())
		{
		try {
				service.updateTrainingProgram(tpbean);
				mv=new ModelAndView("updateTrainingProgram","message","Updated Successfully");
				mv.addObject("isFirst", "true");
		} catch (FeedbackException e) {
				
			mv=new ModelAndView("updateTrainingProgram","message",e.getMessage());
		}
		}
		else
			mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);		
		
		return mv;
	}
	

	
	@RequestMapping("/getTrainingPrgmDetails")
	public ModelAndView getProgramdDetails(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				tpbean=service.getTrainingPrograms(tpbean);
				mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);
			} catch (FeedbackException e) {

				mv= new ModelAndView("updateTrainingProgram","message",e.getMessage());
			}
		}
		else
		{
			mv= new ModelAndView("updateTrainingProgram","tpbean",tpbean);
		}
		return mv;		
	}
	
	
	@RequestMapping("/showPartEnroll")
	public ModelAndView showPartEnroll()
	{
		ParticipantEnrollmentBean pebean=new ParticipantEnrollmentBean();
		
		ModelAndView mv;
		List<TrainingProgramBean> list=null;
		
		try {
			list = service.viewAllTrainingPrograms();
			List<Integer> codeList=new ArrayList<>();
			for(TrainingProgramBean tpbean:list)
			{
				codeList.add(tpbean.getTrainingCode());
			}
			mv= new ModelAndView("enrollParticipant","pebean",pebean);
			mv.addObject("codeList", codeList);
			
		} catch (FeedbackException e) {
			
			mv= new ModelAndView("enrollParticipant","pebean",pebean);
		}
		
		return mv;
		
	}
	
	@RequestMapping("/enrollParticipant")
	public ModelAndView enrollParticipant(@ModelAttribute("pebean") @Valid ParticipantEnrollmentBean pebean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				service.addParticipant(pebean);
				mv=new ModelAndView("enrollParticipant","message","Enrolled Successfully.");
				List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
				List<Integer> codeList=new ArrayList<>();
				for(TrainingProgramBean tpbean:list)
				{
					codeList.add(tpbean.getTrainingCode());
				}
				mv.addObject("codeList", codeList);
				
			} catch (FeedbackException e) {
				mv=new ModelAndView("enrollParticipant","message",e.getMessage());
				e.printStackTrace();
			}
		}
		else
		{
			try {
				mv=new ModelAndView("enrollParticipant","pebean",pebean);
				List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
				List<Integer> codeList=new ArrayList<>();
				for(TrainingProgramBean tpbean:list)
				{
					codeList.add(tpbean.getTrainingCode());
				}
				mv.addObject("codeList", codeList);
			} catch (FeedbackException e) {
				mv=new ModelAndView("enrollParticipant","message",e.getMessage());
			}
		}	
		return mv;
	}
	
	@RequestMapping("/showAddProgram")
	public ModelAndView showAddProgram()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv;
	
		
		List<CourseBean> list=null;
		List<UserBean> list1=null;
		
		
		try {
			
			list = service.viewAllCourses();
			
			List<Integer> codeList=new ArrayList<>();
			for(CourseBean tp1bean:list)
			{
				codeList.add(tp1bean.getCourseID());
			}
			
			list1 = service.viewAllFaculty();
			List<Integer> codeList1=new ArrayList<>();
			for(UserBean tp2bean:list1)
			{
				codeList1.add(tp2bean.getEmpId());
			}
			mv= new ModelAndView("getTraining","tpbean",tpbean);
			mv.addObject("codeList", codeList);
		
			mv.addObject("codeList1", codeList1);
			
		} catch (FeedbackException e) {
			mv= new ModelAndView("getTraining","tpbean",tpbean);
			
		}
		return mv;
		
	}
	
	@RequestMapping("/addTraining")
	public ModelAndView addTraining(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				int tId=service.addTrainingProgram(tpbean);
				mv=new ModelAndView("addTraining","message","Training program added successfully");
				mv.addObject("tId", tId);
			} catch (FeedbackException e) {
				mv=new ModelAndView("addTraining","message",e.getMessage());			
				}
			return mv;
		}
		else
		{
				mv=new ModelAndView("getTraining","tpbean",tpbean);
				
		
		return mv;
	}
	
	
	}
	
	
	
	
	@RequestMapping("/showAllProgram")
	public ModelAndView viewAllProgram()
	{
		ModelAndView mv = new ModelAndView();
		try {
			List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
			if(list.isEmpty()){
				String message = "There are no Training programs";
				mv.setViewName("noProgram");
				mv.addObject("message",message);
			}
			else
			{
				TrainingProgramBean tpbean = new TrainingProgramBean();
				mv.setViewName("viewAlltrainingPgm");
				mv.addObject("list",list);
				mv.addObject("tpbean",tpbean);
				
			}
		} catch (FeedbackException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return mv;
	}
}
