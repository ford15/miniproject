package com.cg.fms.controller;

import java.util.ArrayList;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.SessionAttributes;
import org.springframework.web.servlet.ModelAndView;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.ParticipantEnrollmentBean;
import com.cg.fms.beans.TrainingProgramBean;
import com.cg.fms.beans.UserBean;
import com.cg.fms.exception.FeedbackException;
import com.cg.fms.service.ICoordinatorService;

@Controller
@RequestMapping("*.coo")
@SessionAttributes(value={"session_list1","session_list2","session_list3"})
public class CoordinatorController {

	@Autowired
	ICoordinatorService service;
	
	
	@RequestMapping("/showTrainprgm")
	public ModelAndView showTrainPrgmPage()
	{
		return new ModelAndView("trainingProgramMenu");		
	}
	
	@RequestMapping("/showDeleteProgram")
	public ModelAndView showDeletePage()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv= new ModelAndView("deletetraining","tpbean",tpbean);
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	
	@RequestMapping("/deleteTraining")
	public ModelAndView deleteCourse(@ModelAttribute("tpbean") TrainingProgramBean tpbean)
	{
		ModelAndView mv;
		try {
			tpbean=service.deleteTrainingProgram(tpbean);
			mv=new ModelAndView("deletetraining","tpbean",tpbean);
			mv.addObject("message", "Deleted Successfully");
		} catch (FeedbackException e) {
			
			mv=new ModelAndView("deletetraining","message",e.getMessage());
			mv.addObject("isFirst", "true");
		}
		
		return mv;
	}

	
	@RequestMapping("/showUpdateProgram")
	public ModelAndView showUpdatePage()
	{
	
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv;
		try {
			List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
			List<Integer> codeList=new ArrayList<>();
			for(TrainingProgramBean tbean:list)
			{
				codeList.add(tbean.getTrainingCode());
			}
			 mv= new ModelAndView("updatetraining","tpbean",tpbean);
			mv.addObject("session_list3", codeList);
			mv.addObject("codeList", codeList);
			
		} catch (FeedbackException e) {
			
			mv= new ModelAndView("updatetraining","tpbean",tpbean);
		}
		mv.addObject("isFirst", "true");
		return mv;
	}
	
	
	
	@RequestMapping("/UpdateTrainingPrgm")
	public ModelAndView UpadteProgram(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{

		ModelAndView mv;
		if(!result.hasErrors())
		{
		try {
				service.updateTrainingProgram(tpbean);
				mv=new ModelAndView("updatetraining","message","Updated Successfully");
				mv.addObject("isFirst", "true");
		} catch (FeedbackException e) {
				
			mv=new ModelAndView("updatetraining","message",e.getMessage());
		}
		}
		else
			mv= new ModelAndView("updatetraining","tpbean",tpbean);		
		
		return mv;
	}
	

	
	@RequestMapping("/getTrainingPrgmDetails")
	public ModelAndView getProgramdDetails(@ModelAttribute("tpbean") @Valid TrainingProgramBean tpbean,BindingResult result)
	{
		ModelAndView mv;
		
			try {
				tpbean=service.getTrainingPrograms(tpbean);
				mv= new ModelAndView("updatetraining","tpbean",tpbean);
			} catch (FeedbackException e) {

				mv= new ModelAndView("updatetraining","message",e.getMessage());
			}
	
		return mv;		
	}
	
	
	@RequestMapping("/showPartEnroll")
	public ModelAndView showPartEnroll()
	{
		ParticipantEnrollmentBean pebean=new ParticipantEnrollmentBean();
		
		ModelAndView mv;
		List<TrainingProgramBean> list=null;
		
		try {
			list = service.viewAllTrainingPrograms();
			List<Integer> codeList=new ArrayList<>();
			for(TrainingProgramBean tpbean:list)
			{
				codeList.add(tpbean.getTrainingCode());
			}
			mv= new ModelAndView("enrollParticipant","pebean",pebean);
			mv.addObject("session_list3", codeList);
			mv.addObject("codeList", codeList);
			
		} catch (FeedbackException e) {
			
			mv= new ModelAndView("enrollParticipant","pebean",pebean);
		}
		
		return mv;
		
	}
	
	@RequestMapping("/enrollParticipant")
	public ModelAndView enrollParticipant(@ModelAttribute("pebean") @Valid ParticipantEnrollmentBean pebean,BindingResult result)
	{
		ModelAndView mv;
		if(!result.hasErrors())
		{
			try {
				service.addParticipant(pebean);
				mv=new ModelAndView("enrollParticipant","message","Enrolled Successfully.");
				List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
				List<Integer> codeList=new ArrayList<>();
				for(TrainingProgramBean tpbean:list)
				{
					codeList.add(tpbean.getTrainingCode());
				}
				mv.addObject("codeList", codeList);
				
			} catch (FeedbackException e) {
				mv=new ModelAndView("enrollParticipant","message",e.getMessage());
				
			}
		}
		else
		{
			try {
				mv=new ModelAndView("enrollParticipant","pebean",pebean);
				List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
				List<Integer> codeList=new ArrayList<>();
				for(TrainingProgramBean tpbean:list)
				{
					codeList.add(tpbean.getTrainingCode());
				}
				mv.addObject("codeList", codeList);
			} catch (FeedbackException e) {
				mv=new ModelAndView("enrollParticipant","message",e.getMessage());
			}
		}	
		return mv;
	}
	
	@RequestMapping("/showAddProgram")
	public ModelAndView showAddProgram()
	{
		TrainingProgramBean tpbean=new TrainingProgramBean();
		ModelAndView mv;
	
		
		List<CourseBean> list=null;
		List<UserBean> list1=null;
		
		
		try {
			
			list = service.viewAllCourses();
			
			List<Integer> codeList=new ArrayList<>();
			for(CourseBean tp1bean:list)
			{
				codeList.add(tp1bean.getCourseID());
			}
			
			list1 = service.viewAllFaculty();
			List<Integer> codeList1=new ArrayList<>();
			for(UserBean tp2bean:list1)
			{
				codeList1.add(tp2bean.getEmpId());
			}
			mv= new ModelAndView("addtraining","tpbean",tpbean);
			mv.addObject("session_list1", codeList);	
			mv.addObject("session_list2", codeList1);
			
		} catch (FeedbackException e) {
			mv= new ModelAndView("addtraining","tpbean",tpbean);
			
		}
		return mv;
		
	}
	
	@RequestMapping("/addTraining")
	public ModelAndView addTraining(@ModelAttribute("tpbean") TrainingProgramBean tpbean)
	{
		ModelAndView mv;
		List<CourseBean> list=null;
		List<UserBean> list1=null;

			try {
				int tId=service.addTrainingProgram(tpbean);
			
				mv=new ModelAndView("addtraining","message","Training program added successfully");
				
				mv.addObject("tId","Training Code is "+tId);
			} catch (FeedbackException e) {
				mv=new ModelAndView("addtraining","message",e.getMessage());
		}

			
		return mv;
		
	}
	
	
	
	@RequestMapping("/showAllProgram")
	public ModelAndView viewAllProgram()
	{
		ModelAndView mv = new ModelAndView();
		try {
			List<TrainingProgramBean> list = service.viewAllTrainingPrograms();
			if(list.isEmpty()){
				String message = "There are no Training programs";
				mv.setViewName("noProgram");
				mv.addObject("message",message);
			}
			else
			{
				TrainingProgramBean tpbean = new TrainingProgramBean();
				mv.setViewName("viewAllTraining");
				mv.addObject("list",list);
				mv.addObject("tpbean",tpbean);
				
			}
		} catch (FeedbackException e) {
		}
		return mv;
	}
}
