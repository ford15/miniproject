package com.cg.fms.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.fms.beans.FeedbackBean;
import com.cg.fms.exception.FeedbackException;

@Repository
@Transactional
public class ParticipantDaoImpl implements IParticipantDao
{
	@PersistenceContext
	EntityManager em;

	/****************************************************************************************************************************
	 - Method Name      : addFeedback
	 - Input Parameters : FeedbackBean fbean
	 - Return type      : int
	 - Author           : Dheerendra Panderiya, Sri Raksha
	 - Creation Date    : 17-02-2018
	 - Description      : Inserting the participant Feedback into the database.
	  ****************************************************************************************************************************/
	@Override
	public int addFeedback(FeedbackBean bean) throws FeedbackException {
		
		try {
			em.persist(bean);
		} catch (Exception e) {
			throw new FeedbackException("Unable to Add Feedback");
		}
		return bean.getParticipant_id();
	}

}
