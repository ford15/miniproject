package com.cg.fms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Max;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import org.hibernate.validator.constraints.NotBlank;

@Entity
@Table(name="employee_master")
public class UserBean {

	@Id
	@Column(name="employee_id")
	@Min(1)
	@NotNull
	private int empId;

	@Column(name="employeename")
	private String empName;
	
	@Column(name="password")
	@NotNull
	@Pattern(regexp="[a-zA-Z@0-9]+",message="Password must contain only (alphabets,0-9,@)")
	private String password;
	
	@Column(name="role")
	private String role;
	
	
	public int getEmpId() {
		return empId;
	}
	public void setEmpId(int empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRole() {
		return role;
	}
	public void setRole(String role) {
		this.role = role;
	}
	public UserBean() {
		super();
		// TODO Auto-generated constructor stub
	}
	
	
}
