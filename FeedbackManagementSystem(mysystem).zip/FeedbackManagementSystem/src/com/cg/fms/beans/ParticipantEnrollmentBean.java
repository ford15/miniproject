package com.cg.fms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name="training_enrollment")
public class ParticipantEnrollmentBean {

	@Id
	@Column(name="enroll_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int enrollId;
	@Column(name="training_code")
	private int trainingCode;
	@Column(name="participant_id")
	private int participantId;
	
	public ParticipantEnrollmentBean() {
		super();
	}
	
	public ParticipantEnrollmentBean(int trainingCode, int participantId) {
		super();
		this.trainingCode = trainingCode;
		this.participantId = participantId;
	}
	
	public int getTrainingCode() {
		return trainingCode;
	}
	
	public void setTrainingCode(int trainingCode) {
		this.trainingCode = trainingCode;
	}
	
	public int getParticipantId() {
		return participantId;
	}
	
	public void setParticipantId(int participantId) {
		this.participantId = participantId;
	}
	
	
}
