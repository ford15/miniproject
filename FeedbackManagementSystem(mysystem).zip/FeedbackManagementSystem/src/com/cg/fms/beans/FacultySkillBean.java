package com.cg.fms.beans;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.Pattern;


@Entity
@Table(name="faculty_skill")
public class FacultySkillBean 
{
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int skillCode;
	@Min(value=1000,message="Enter ID between 1000-9999")
	@Column(name="faculty_id")
	private int facutlyId;
	@Column(name="skill_set")
	@Pattern(regexp="[a-zA-Z]+[ a-zA-Z.#+,]",message="Enter Valid SkillSet")
	private String skillSet;
	
	public int getSkillCode() {
		return skillCode;
	}

	public void setSkillCode(int skillCode) {
		this.skillCode = skillCode;
	}

	
	public int getFacutlyId() {
		return facutlyId;
	}
	
	public void setFacutlyId(int facutlyId) {
		this.facutlyId = facutlyId;
	}
	
	public String getSkillSet() {
		return skillSet;
	}
	
	public void setSkillSet(String skillSet) {
		this.skillSet = skillSet;
	}
	
	

}
