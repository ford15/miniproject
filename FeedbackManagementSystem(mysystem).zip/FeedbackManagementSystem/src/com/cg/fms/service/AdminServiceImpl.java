package com.cg.fms.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.fms.beans.CourseBean;
import com.cg.fms.beans.FacultySkillBean;
import com.cg.fms.dao.IAdminDao;
import com.cg.fms.exception.FeedbackException;

@Service
public class AdminServiceImpl implements IAdminService{

	@Autowired
	IAdminDao dao;
	
	@Override
	public int addCourse(CourseBean bean) throws FeedbackException {

		return dao.addCourse(bean);
	}

	@Override
	public List<CourseBean> viewAllCourses() throws FeedbackException {
		return dao.viewAllCourses();
	}

	@Override
	public CourseBean deleteCourse(int courseId) throws FeedbackException {
		return dao.deleteCourse(courseId);
	}

	

	@Override
	public void updateCourse(CourseBean bean) throws FeedbackException {
		dao.updateCourse(bean);
	}

	@Override
	public CourseBean getCourse(CourseBean bean) throws FeedbackException {
		return dao.getCourse(bean);
	}

	@Override
	public int addFaculty(FacultySkillBean fbean) throws FeedbackException {
		return dao.addFaculty(fbean);
	}

	
}
