var restify = require('restify');
var builder = require('botbuilder');
var read = require('jsonfile');
var tolower = require('to-lower-case')
var synonym = require('synonym-js')
var sortObj = require('sort-object');
var randomItem = require('random-item');
var fs = require('fs');
// Setup Restify Server
var server = restify.createServer();
server.listen(process.env.port || process.env.PORT || 3978, function () {
   console.log('%s listening to %s', server.name, server.url); 
});

var contents = read.readFileSync('data_fetch20.0.json');
var heads = read.readFileSync('data_fetch_head.json')
var spoc = read.readFileSync('account_spoc.json')
var lookup = read.readFileSync('city_lookup.json')
var StoreLoc;
var StoreResponse;
var StoreResult;
var StoreResult2;
var StoreDesignation;
var StoreSub;
var StoreSkill;
var StoreDes;
var StoreCountry;
var StoreAcc;
var StoreDiv;
var StoreState;
var Sub1
var Loc1

var date = new Date();
var LocArray = new Array();
var SkillSet = new Array();
var SkillArr = new Array();
var SubPracticeArray = new Array();
var SubPracticeArr = new Array();
var HelpArray = new Array();
var items = ["Bye!","Have a nice day!","Thank you. Bye.","See you later."]
HelpArray=["Can I get contact information of 'Expert Name'","Who is the head of 'Sub-practice'","Show me contacts in 'Location'","Show me info of 'Sub-practice' expert","I need help with 'Skill'", "Show me I&D spoc for 'Account Name'"]
//randomItem(["Bye!","Have a nice day!","Thank you. Bye.","See you later."]);
// Create chat connector for communicating with the Bot Framework Service
//var item = items[Math.floor(Math.random()*items.length)];
//var item =  items.shuffle()[0];





var connector = new builder.ChatConnector({
    appId: process.env.MicrosoftAppId,
    appPassword: process.env.MicrosoftAppPassword
});

// Listen for messages from users +
server.post('/api/messages', connector.listen());

// Receive messages from the user and respond by echoing each message back (prefixed with 'You said:')
/*var bot = new builder.UniversalBot(connector, function (session) {
    session.send("You said: %s", session.message.text);
});*/
function GetValues(session,args, args1){
	//console.log(31)
	var count=0;
	console.log(args1.entity)


	if(tolower(args)=='all'){
session.send('Here are the details of all the people working at  \'%s\' ',args1)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		if (tolower(contents[i].Location)==tolower(args1)) {
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}
session.beginDialog('getMessage');
	}
	else{
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var j=0; j<contents[i].Skill.length;j++){
	if ((tolower(contents[i].Skill[j])==tolower(args)) && (tolower(contents[i].Location)==tolower(args1))) {
							count++;
		}
	}
}
if(count>0)
	{
		for(var i=0; i<contents.length;i++){  
		console.log('hey')
		for(var j=0; j<contents[i].Skill.length;j++){
	if ((tolower(contents[i].Location)==tolower(args1)) && (tolower(contents[i].Skill[j])==tolower(args))) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',args1,args,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		
		}
	}
}
	}

	else if(count==0){
		 session.beginDialog('helpmenualt')
		    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
		
	}
	
session.beginDialog('getMessage');
}
}


function GetSubLoc(session,sub, loc){
	//console.log(31)
	var count=0;
	SkillArr=[];
	//console.log(loc.entity)
var array= new Array();
	for(var i=0; i<contents.length;i++)
	{ 
		for(var j=0;j<contents[i].SubPractice.length;j++){
		console.log('hi')
	if ((tolower(contents[i].SubPractice[j])==tolower(sub)) && (tolower(contents[i].Location)==tolower(loc)))
	 {console.log('count')
							count++;
		}
	}
}
if(count>1){
	for(var i=0; i<contents.length;i++){  
		console.log('hey')
		for(var j=0;j<contents[i].SubPractice.length;j++){
		if ((tolower(contents[i].SubPractice[j])==tolower(sub)) && (tolower(contents[i].Location)==tolower(loc))) {
for(var k=0;k<contents[i].Skill.length;k++){
				
				if(contents[i].Skill[k]!=null || contents[i].Skill[k]!="")
			array.push(contents[i].Skill[k]);
			//SkillSet[k]=temp;
	}
	/*SkillSet.sort();
	console.log('hello')
	console.log(SkillSet)
	console.log('hi')*/

	}
	//console.log(count)
	
}
}

array.sort();
var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(SkillArr)
//session.send('The skills: \'%s\' are available for people working with \'%s\' in \'%s\'',SkillArr,sub,loc)
Sub1=sub;
Loc1=loc;
session.beginDialog('getskillforsubloc')

}


if(count==1)
	{
		for(var i=0; i<contents.length;i++){  
		console.log('hey')
		for(var j=0; j<contents[i].SubPractice.length; j++){
		if ((tolower(contents[i].SubPractice[j])==tolower(sub)) && (tolower(contents[i].Location)==tolower(loc))) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n  Practice: \'%s\'  \n \n   Email: \'%s\'.',loc,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		session.beginDialog('getMessage');
		}
	}
}
}	

	else if(count==0){
		     session.beginDialog('helpmenualt')
		        console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
	

}


function GetDialogForHeadSubKill(session){
session.beginDialog('HeadSubSkill')
}

function GetValuesForSubSkill(session,sub, skill){
	//console.log(31)
	console.log(sub)
	console.log(skill)
	var count=0

	if(tolower(skill)=='all'){
session.send('Here are the details of all the people with subpractice: \'%s\' ',sub)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var k=0; k<contents[i].SubPractice.length;k++){

		if (tolower(contents[i].SubPractice[k])==tolower(sub)) {
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}
}
session.beginDialog('getMessage');
	}
	else{
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var j=0; j<contents[i].Skill.length;j++){
			for(var k=0; k<contents[i].SubPractice.length;k++){
	if ((tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Skill[j])==tolower(skill))) {
			count++;
			//session.send('Here are the details you were looking for:  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)				
		
		}
	}
}
}
if(count>0){
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var j=0; j<contents[i].Skill.length;j++){
			for(var k=0; k<contents[i].SubPractice.length;k++){
	if ((tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Skill[j])==tolower(skill))) {
			//count++;
			session.send('Here are the details you were looking for:  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)				
		
		}
	}
}
}
}
else if(count==0){
		     session.beginDialog('helpmenualt')
		        console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
session.beginDialog('getMessage');
}
}


function GetValuesForSubDes(session,sub, des){
	//console.log(31)
	var count=0;
	console.log(des.entity)
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		//console.log('hi')
		for(var k=0; k<contents[i].SubPractice.length;k++)
		{
	if ((tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Designation)==tolower(des))) {
							count++;
		}
	}

}
if(count>0){

for(var i=0; i<contents.length;i++){  
		//console.log('hey')
		//console.log(args)
		//console.log(args1)
		for(var k=0; k<contents[i].SubPractice.length;k++)
		{
	if ((tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Designation)==tolower(des))) {
							//count++;
			//session.send('output')
			session.send('Here are the details of \'%s\' of practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',des,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		
		}
	}
	}
	session.beginDialog('getMessage');
}
else{

	 session.beginDialog('helpmenualt')
	    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}


function GetValues3(session,args,args1,args2){
	//console.log(31)
	var count=0;
	//console.log(args1.entity)
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		//console.log('hi')
	if ((tolower(contents[i].Location)==tolower(args)) && (tolower(contents[i].Designation)==tolower(args1)) && (tolower(contents[i].SubPractice)==tolower(args2))) {
							count++;
		}
	}

if(count>1)
	{
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		//console.log('hi')
	if ((tolower(contents[i].Location)==tolower(args)) && (tolower(contents[i].Designation)==tolower(args1)) && (tolower(contents[i].SubPractice)==tolower(args2))) {
							session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',args1.entity,args,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		
		}
	}session.beginDialog('getMessage');
		//session.send('count is high......')
		//session.beginDialog('getLoc');	// begin a dialog: getSkill ** Navigate to Line: 173
	}
	else{

for(var i=0; i<contents.length;i++){  
		//console.log('hey')
		//console.log(args)
		//console.log(args1)
	if ((tolower(contents[i].Location)==tolower(args)) && (tolower(contents[i].Designation)==tolower(args1)) && (tolower(contents[i].SubPractice)==tolower(args2))) {
			session.send('output')
			//session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',args1.entity,args,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		}
	}
	}
}


//GetValuesForDesSubCountry
function GetValuesForDesSubCountry(session,skill,country,sub,des){
	//console.log(57)
	var count=0;
		console.log('hsss')
	console.log(des)
	console.log(sub.entity)
		console.log('hkkkk')
	console.log(des)
	console.log(skill)

	if(tolower(skill)=='all'){
session.send('Here are the details of all the people with subpractice \'%s\' with designation \'%s\' working in \'%s\'',sub,des,country)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(k=0;k<contents[i].SubPractice.length;k++){
		if (tolower(contents[i].SubPractice[k])==tolower(sub) && tolower(contents[i].Designation)==tolower(des) && tolower(contents[i].Country)==tolower(country)) {
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}
}
session.beginDialog('getMessage');
	}
	else{
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubCountry')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(k=0;k<contents[i].SubPractice.length;k++){
if ((tolower(contents[i].Designation)==tolower(des)) &&(tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Country)==tolower(country)) ) {
			console.log('ggggg');
			count++;	
		}
}
}}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubCountrylll')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(k=0;k<contents[i].SubPractice.length;k++){
		if ((tolower(contents[i].Designation)==tolower(des)) &&(tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Country)==tolower(country)) ) {
			console.log('ggggg');
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',country,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
}
session.beginDialog('getMessage');
}
else if(count==0){
    session.beginDialog('helpmenualt')
       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});

}
}}

//GetValuesForSubCountry
function GetValuesForSubCountry(session,skill,country,sub){
	//console.log(57)
	var count=0;
	console.log(sub.entity)
	console.log(country.entity)
	console.log(skill)

	if(tolower(skill)=='all'){
session.send('Here are the details of all the people with subpractice \'%s\' in country \'%s\'',sub,country)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var k=0; k<contents[i].SubPractice.length;k++){
		if (tolower(contents[i].SubPractice[k])==tolower(sub) && tolower(contents[i].Country)==tolower(country)) {
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}
}
session.beginDialog('getMessage');
	}
	else{
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubCountry')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(var k=0; k<contents[i].SubPractice.length;k++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Country)==tolower(country)) ) {
			count++;	
		}
}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubCountrylll')
		for(var j=0;j<contents[i].Skill.length;j++){

			for(var k=0; k<contents[i].SubPractice.length;k++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Country)==tolower(country)) ) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',country,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
}
session.beginDialog('getMessage');
}
else if(count==0){
    session.beginDialog('helpmenualt')
       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});

}
}
}


function GetMessage(session,message){
	//console.log(57)
	console.log(message)
	
	if (tolower(message)=='yes') {
			session.send('How may I assist you today?');	
		}
		else if(tolower(message)=='no'){
			session.send('Thanks for using Chatbot. Hope this helps!  \n \n   \n \n  Please reach out to following for feedback:  \n \n  1) Gunjan Aggarwal: gunjan.aggarwal@capgemini.com,  \n \n  2) Sheng Zhang:  sheng.a.zhang@capgemini.com and  \n \n  3) Anjan Chartterjee: anjan.chatterjee@capgemini.com');

		}

}
//GetValuesSkillSubLoc
function GetValuesSkillSubLoc(session,skill,sub,loc){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubLocSkill')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].Location)==tolower(loc)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubLocSkill')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].Location)==tolower(loc)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working in \'%s\' with skill \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',loc,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}

//GetValuesHeadSkillSubCountry
function GetValuesHeadSkillSub(session,skill,sub){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('headcountry')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('heaaaaadddddcountry')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working under subpractice \'%s\' with skill \'%s\'   \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',sub,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}

function GetValuesHeadSkillSubDef(session,skill,sub){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('headdef')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('heaaaaaddddddef')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working under subpractice \'%s\' with skill \'%s\'   \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',sub,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
session.beginDialog('getMessage');
}}


function GetValuesHeadSkillSub(session,skill,sub){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('headcountry')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('heaaaaadddddcountry')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working under subpractice \'%s\' with skill \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',sub,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}


function GetValuesHeadSkillSubCountry(session,skill,sub,country){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('headcountry')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Country)==tolower(country))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('heaaaaadddddcountry')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Country)==tolower(country))) {
			session.send('Here are the details of people working under subpractice \'%s\' with skill \'%s\' and in \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',sub,skill,country,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}

function GetValuesHeadSkillSubLocation(session,skill,sub){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('headloc')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('heaaaaadddddloc')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working under subpractice \'%s\' with skill \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',sub,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}



function GetValuesHeadSkillSubState(session,skill,sub){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('headstate')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('heaaaaadddddstate')
		for(var k=0;k<contents[i].SubPractice.length;k++)
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working under subpractice \'%s\' with skill \'%s\'   \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',sub,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}


//GetValuesForSubLocSkill
function GetValuesForSubLocSkill(session,sub,loc,skill){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
	console.log(sub)
	
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubLocSkill')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(var k=0;k<contents[i].SubPractice.length;k++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].Location)==tolower(loc)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			count++;	
		}
}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubLocSkillllll')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(var k=0;k<contents[i].SubPractice.length;k++){
if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].Location)==tolower(loc)) && (tolower(contents[i].SubPractice[k])==tolower(sub))) {
			session.send('Here are the details of people working in \'%s\' with skill \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',loc,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
}
session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}


function GetValuesSkillLoc(session,loc,skill){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
		if(tolower(loc)=='all'){
session.send('Here are the details of all the people with skill \'%s\' ',skill)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var j=0;j<contents[i].Skill.length;j++){
		if (tolower(contents[i].Skill[j])==tolower(skill)) {
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}}

	}
	else{
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('LocFilterOnSkill')
		for(var j=0;j<contents[i].Skill.length;j++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].Location)==tolower(loc))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('LocFilterOnSkilllll')
		for(var j=0;j<contents[i].Skill.length;j++){
			console.log('In for')
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].Location)==tolower(loc))) {

			session.send('Here are the details of people working in \'%s\' with skill \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',loc,skill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});

}
}
session.beginDialog('getMessage');
}


function GetValuesForLocAcc(session,loc,acc){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	//console.log(skill)
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('LocFilterOnAcc')
		for(var j=0;j<contents[i].Account.length;j++){
		if ((tolower(contents[i].Account[j])==tolower(acc)) && (tolower(contents[i].Location)==tolower(loc))) {
			count++;	
		}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('LocFilterOnSAccccc')
		for(var j=0;j<contents[i].Account.length;j++){
		if ((tolower(contents[i].Account[j])==tolower(acc)) && (tolower(contents[i].Location)==tolower(loc))) {
			session.send('Here are the details of people working in \'%s\' in account \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',loc,acc,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}

session.beginDialog('getMessage');
}
else if(count==0){
	   
	   session.beginDialog('helpmenualt')
	      console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}



// SubAccSkill
function GetValuesForSubDiv(session,skill,div,sub){
	//console.log(57)
	var count=0;
	//console.log(sub.entity)
	//console.log(div.entity)
	console.log(skill)
		if(tolower(skill)=='all'){
session.send('Here are the details of all the people with subpractice \'%s\' and in division  \'%s\'',sub,div)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var k=0; k<contents[i].SubPractice.length; k++){
			console.log('for loop')
		if (tolower(contents[i].SubPractice[k])==tolower(sub) && tolower(contents[i].Division)==tolower(div)) {
			console.log('Hello')
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}
}
//session.beginDialog('getMessage');
	}
	else{
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubDiv')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(var k=0; k<contents[i].SubPractice.length; k++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Division)==tolower(div)) ) {
			count++;	
		}
}
}
}
if(count>0){
		for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('GetValuesForSubDivlll')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(var k=0; k<contents[i].SubPractice.length; k++){
		if ((tolower(contents[i].Skill[j])==tolower(skill)) && (tolower(contents[i].SubPractice[k])==tolower(sub)) && (tolower(contents[i].Division)==tolower(div)) ) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',div,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
}
session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}

}
//SubCountryLoc
function SubAccSkill(session,sub,acc,skill){
	//console.log(57)
	var count=0;
	console.log(sub.entity)
	console.log(acc)
	console.log(skill)
if(tolower(skill)=='all'){
session.send('Here are the details of all the people with subpractice \'%s\' in account \'%s\'',sub,acc)
for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('hi')
		for(var j=0;j<contents[i].SubPractice.length;j++){	
	for(var k=0;k<contents[i].Account.length;k++){	
		if (tolower(contents[i].SubPractice[j])==tolower(sub) && tolower(contents[i].Account[k])==tolower(acc)) {
		session.send('Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n    Skills: \'%s\'  \n \n   Email: \'%s\'.',contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Skill,contents[i].Email)					
}
}
}

}	
}
else
{

	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('SubAccSkill')
		for(var j=0;j<contents[i].Skill.length;j++){
			console.log('SubAccSkill')
			for(var k=0;k<contents[i].Account.length;k++){
				for(var m=0;m<contents[i].SubPractice.length;m++){
	if ((tolower(contents[i].Account[k])==tolower(acc)) && (tolower(contents[i].SubPractice[m])==tolower(sub)) && (tolower(contents[i].Skill[j])==tolower(skill)) ) {
			count++;	
		}
}
}
}
}
if(count>=1){
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('kkkkk')
		for(var j=0;j<contents[i].Skill.length;j++){
			for(var k=0;k<contents[i].Account.length;k++){
				for(var m=0;m<contents[i].SubPractice.length;m++){
	if ((tolower(contents[i].Account[k])==tolower(acc)) && (tolower(contents[i].SubPractice[m])==tolower(sub)) && (tolower(contents[i].Skill[j])==tolower(skill)) ) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',acc,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
}
}
}
session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});

}
}
}


function SubCountryLoc(session,sub,cont,loc){
	//console.log(57)
	var count=0;
	console.log(sub.entity)
	console.log(cont)
	console.log(loc)
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('SubCountryLoc')
	if ((tolower(contents[i].Country)==tolower(cont)) && (tolower(contents[i].SubPractice)==tolower(sub)) && (tolower(contents[i].Location)==tolower(loc)) ) {
			count++;	
		}
}
if(count>=1){
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('jjjjjjj')
	if ((tolower(contents[i].Country)==tolower(cont)) && (tolower(contents[i].SubPractice)==tolower(sub)) && (tolower(contents[i].Location)==tolower(loc)) ) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',cont,sub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}
}
session.beginDialog('getMessage');
}
else if(count==0){
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}

function GetValues1(session,args,args1,args2){
	//console.log(57)
	var count=0;
	console.log(args1.entity)
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('get values 1')
	for(var j=0; j<contents[i].Skill.length;j++){
	if ((tolower(contents[i].Location)==tolower(args1)) && (tolower(contents[i].Skill[j])==tolower(args)) && (tolower(contents[i].Designation)==tolower(args2)) ) {
			count++;	
		}

	}
}
if(count>=1){
	for(var i=0; i<contents.length;i++){  // Write the File logic here
		console.log('get values 1')
	for(var j=0; j<contents[i].Skill.length;j++){
	if ((tolower(contents[i].Location)==tolower(args1)) && (tolower(contents[i].Skill[j])==tolower(args)) && (tolower(contents[i].Designation)==tolower(args2)) ) {
			session.send('Here are the details of people working in \'%s\' with practice \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',args1.entity,args,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)	
		
		}

	}
}
session.beginDialog('getMessage');
}
else if(count==0){
   session.beginDialog('helpmenualt')
      console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}

var bot = new builder.UniversalBot(connector);

bot.on('conversationUpdate', function (message) {
  if (message.membersAdded) {
      message.membersAdded.forEach(function (identity) {
          if (identity.id === message.address.bot.id) {
              var reply = new builder.Message()
                  .address(message.address)
                  .text('I am Anna, the Capgemini chatbot. I can help you to find right contact from "Insights and Data" team.');
                  
              bot.send(reply);
              
          }
      });
  }
});

const LuisModelUrl='https://westus.api.cognitive.microsoft.com/luis/v2.0/apps/91341f20-6d4e-4661-aa69-adfc1fc45779?subscription-key=4d06667a63354dd3982cbbdf72aab436&spellCheck=true&bing-spell-check-subscription-key=2c1ec15508af4387b611a988b41a5812&verbose=true&timezoneOffset=0&q='

var recognizer = new builder.LuisRecognizer(LuisModelUrl);
//bot.recognizer(recognizer);
//console.log(recognizer);
//console.log('baahubali')
var intents = new builder.IntentDialog({ recognizers: [recognizer] })

.matches('greet', function(session,args){
 //var entityName = builder.EntityRecognizer.findEntity(args.entities, 'Designation');
//console.log(entityName);
//session.send('Hello.')
var username = session.message.user.name;
var userid = session.message.address.user.id
session.send('Hi, \'%s\'. How may I assist you today? Type \'help\' for some sample queries',username)
//session.send('Hi, \'%s\'. How may I assist you today? Type \'help\' for some sample queries',user2)
//session.beginDialog('getUsername');

})

.matches('AskUser', function(session,args){
 var entityresp = builder.EntityRecognizer.findEntity(args.entities, 'askuser');
//console.log(entityName);
if(tolower(entityresp.entity)=='do something'||tolower(entityresp.entity)=='search'||tolower(entityresp.entity)=='yeah'||tolower(entityresp.entity)=='yes')
{
	session.send('How may I assist you today?')
}
//session.beginDialog('getUsername');
if(tolower(entityresp.entity)=='no'||tolower(entityresp.entity)=='nothing'){
	session.send('Thanks for using Chatbot. Hope this helps!  \n \n   \n \n  Please reach out to following for feedback:  \n \n  1) Gunjan Aggarwal: gunjan.aggarwal@capgemini.com,  \n \n  2) Sheng Zhang:  sheng.a.zhang@capgemini.com and  \n \n  3) Anjan Chartterjee: anjan.chatterjee@capgemini.com')
}

})

.matches('end_greet', function(session,args){
 //var entityName = builder.EntityRecognizer.findEntity(args.entities, 'Designation');
//console.log(entityName);
session.send(randomItem(items))
})

/*.matches('help', function(session,args){
session.send('right now I am unable to find that option, please put your note here, I will connect with right person')
})*/

.matches('help', function(session,args){

session.beginDialog('helpmenu')
})

.matches('getEmail', function(session,args){
	var entity_fname = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
	if(entity_fname == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(entity_fname.entity);
var count=0;
for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].FirstName)==tolower(entity_fname.entity)) {
		session.send(contents[i].Email)
		count++;
			session.beginDialog('getMessage');
	}
}
	if(count==0)
	{   session.beginDialog('helpmenualt')
   console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
}
})



.matches('account_spoc', function(session,args){
	var account = builder.EntityRecognizer.findEntity(args.entities, 'account_spoc_e');
	if(account == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(account.entity);
var count=0;
for(var i=0; i<spoc.length;i++){
	if (tolower(spoc[i].Account)==tolower(account.entity)) {
		count++;
	}
}
	if(count==0)
	{   session.beginDialog('helpmenualt')
   console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
	else{
		for(var i=0; i<spoc.length;i++){
	if (tolower(spoc[i].Account)==tolower(account.entity)) {
		session.send("The leaders you are looking for are \'%s\'",spoc[i].Leader)
			session.beginDialog('getMessage');
	}
	}
}
} 
})



.matches('getContactInformation', function(session,args){
	var entity_fname = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
	if(entity_fname == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(entity_fname.entity);
var count=0;
for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].FirstName)==tolower(entity_fname.entity)) {
		
		count=1;
	}
}
	if(count==0)
	{    session.beginDialog('helpmenualt')
   console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
	else{
		for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].FirstName)==tolower(entity_fname.entity)) {
		session.send('Here are the details of \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',contents[i].FirstName,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)
	session.beginDialog('getMessage');
	}
	}
}
}
})
.matches('head_skill', function(session,args){
	var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
//console.log(entity_fname.entity);
var array= new Array()
SkillArr=[];
if(entity_sub == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
	for(var j=0;j<entity_sub.resolution.values.length;j++){
			StoreSub=entity_sub.resolution.values[j]
		}

var count=0;
var fname = new Array();
var lname = new Array();
for(var i=0; i<heads.length;i++){
	for(var j=0; j<heads[i].SubPractice.length;j++){
if(tolower(heads[i].SubPractice[j]) == tolower(StoreSub)){
	fname.push(heads[i].FirstName);
	lname.push(heads[i].LastName);
	}
	/*else{
		session.send('There\'s no head for this sub practice.')
			session.beginDialog('getMessage');
	}*/
}
}


for(var i=0; i<contents.length;i++){
	for(var j=0;j<fname.length;j++){
		for(var k=0;k<lname.length;k++){
	if (tolower(contents[i].FirstName)==tolower(fname[j]) && tolower(contents[i].LastName)==tolower(lname[k])) {
		
		count=1;

	}
	for(var m=0;m<contents[i].SubPractice.length;m++){
		for(var n=0;n<contents[i].Skill.length;n++){

if(tolower(contents[i].SubPractice[m]) == tolower(StoreSub)){
				//console.log(temp)
				if(contents[i].Skill[n]!=null || contents[i].Skill[n]!="")
			array.push(contents[i].Skill[n]);
			//SkillSet[k]=temp;
	}
}
}
}
}
}
array.sort();
	console.log('hello')
	//console.log(SkillSet)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(SkillArr)



	if(count==0)
	{     session.beginDialog('helpmenualt')
   console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
	else{
		for(var i=0; i<contents.length;i++){
			for(var j=0;j<fname.length;j++){
		for(var k=0;k<lname.length;k++){
	if (tolower(contents[i].FirstName)==tolower(fname[j]) && tolower(contents[i].LastName)==tolower(lname[k])) {
		session.send('Here are the details of the head for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',StoreSub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)
	
}}
	}
	}

}

session.beginDialog('AskForSkillOnHead');
}

})


.matches('getPhone', function(session,args){
	var entity_fname = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
console.log(entity_fname.entity);
var count=0;
if(entity_fname == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].FirstName)==tolower(entity_fname.entity)) {
		count++;
		console.log('hello')
	}
}
	if(count==0)
	{
		   session.beginDialog('helpmenualt')
		      console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
	else{

		for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].FirstName)==tolower(entity_fname.entity)) {
		session.send(contents[i].phone)
		
	}
}
session.beginDialog('getMessage');
	}
}
})


.matches('getEmail_l', function(session,args){
	var entity_lname = builder.EntityRecognizer.findEntity(args.entities, 'last_name');
//console.log(entity_fname.entity);
if(entity_lname == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
var count=0;
for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].LastName)==tolower(entity_lname.entity)) {
		session.send(contents[i].Email)
		count=1;
	}
}
session.beginDialog('getMessage');
	/*if(count==0)
	{
		session.send('No data found for \'%s\'',entity_fname.entity)
	}*/
}
})


.matches('ContactsWorkingFor', function(session,args){
	//console.log(contents);
var count=0
var array= new Array();
LocArray=[]
var entity_account = builder.EntityRecognizer.findEntity(args.entities, 'account');
if(entity_account == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

for(var j=0;j<entity_account.resolution.values.length;j++){
			StoreAcc=entity_account.resolution.values[j]
		}
console.log(StoreAcc);
//session.send('Can you add more filters to the data')
for(var i=0; i<contents.length;i++){
//	console.log(contents[i].Account);
	for(var j=0; j<contents[i].Account.length;j++){
		//console.log(contents[i].Account[j]);
	if (tolower(contents[i].Account[j])==tolower(StoreAcc)) {
		console.log('hello')


		array.push(contents[i].Location);
	    //session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreAcc,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	count++
	}
	/*else
	{
		session.send('no such information found')
	}*/
}
}
array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                LocArray[j++] = array[i];  
            }  
         }  
        LocArray[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(LocArray)
if(count>1){
	console.log('More than 1')
	console.log(LocArray)
	session.beginDialog('LocFilterOnAcc');
	//session.beginDialog('getMessage');
}
else if(count==1){
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].Account.length;j++){
		//console.log(contents[i].Account[j]);
	if (tolower(contents[i].Account[j])==tolower(StoreAcc)) {
		console.log('hello')
		//count++;
	   session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreAcc,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		//session.send('output')
	}
	/*else
	{
		session.send('no such information found')
	}*/
}
}
session.beginDialog('getMessage');
}
else{
	 session.beginDialog('helpmenualt')
	    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}


}

})



.matches('location_skill', function(session,args){
	//console.log(contents);

var entity_skill = builder.EntityRecognizer.findEntity(args.entities, 'skillset');
var entity_loc = builder.EntityRecognizer.findEntity(args.entities, 'location');
var count=0
var array= new Array();
SubPracticeArr=[]
if(entity_loc == null || entity_skill == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

for(var j=0;j<entity_skill.resolution.values.length;j++){
			StoreSkill=entity_skill.resolution.values[j]
		}
		for(var j=0;j<entity_loc.resolution.values.length;j++){
			StoreLoc=entity_loc.resolution.values[j]
		}
		console.log(StoreLoc)
		console.log(StoreSkill)
//console.log(entity_account.entity);
//session.send('Can you add more filters to the data')
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].Skill.length;j++){
		//console.log(contents[i].Account[j]);
		for(var k=0;k<contents[i].SubPractice.length;k++){
	if (tolower(contents[i].Skill[j])==tolower(StoreSkill) && tolower(contents[i].Location)==tolower(StoreLoc)) {
		console.log('hello')
array.push(contents[i].SubPractice[k]);
		count++;
	   //session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_skill.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		//session.send('output')
	}
	/*else
	{
		session.send('no such information found')
	}*/
}
}
}
array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SubPracticeArr[j++] = array[i];  
            }  
         }  
        SubPracticeArr[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(SubPracticeArr)

if(count>1){
	console.log('More than 1')
	session.beginDialog('SubFilterOnSkillLoc');
	//session.beginDialog('getMessage');
}
else if(count==1){
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].Skill.length;j++){
		//console.log(contents[i].Account[j]);
	if (tolower(contents[i].Skill[j])==tolower(StoreSkill) && tolower(contents[i].Location)==tolower(StoreLoc)){
		console.log('hello')
		//count++;
	   session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreSkill,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		//session.send('output')
	}
	/*else
	{
		session.send('no such information found')
	}*/
}
}
session.beginDialog('getMessage');
}
else{
	 session.beginDialog('helpmenualt')
	    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}

}

})


.matches('account_skill', function(session,args){
	//console.log(contents);

var entity_skill = builder.EntityRecognizer.findEntity(args.entities, 'skillset');
var entity_acc = builder.EntityRecognizer.findEntity(args.entities, 'account');
//console.log(entity_account.entity);
//session.send('Can you add more filters to the data')
if(entity_acc == null || entity_skill == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
for(var j=0;j<entity_skill.resolution.values.length;j++){
			StoreSkill=entity_skill.resolution.values[j]
		}
		for(var j=0;j<entity_acc.resolution.values.length;j++){
			StoreAcc=entity_acc.resolution.values[j]
		}
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].Skill.length;j++){
		for(var k=0;k<contents[i].Account.length;k++){
		//console.log(contents[i].Account[j]);
	if (tolower(contents[i].Skill[j])==tolower(StoreSkill) && tolower(contents[i].Account[k])==tolower(StoreAcc)) {
	    session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_skill.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		}
}
	/*else
	{
		session.send('no such information found')
	}*/
}
}

session.beginDialog('getMessage');
}
})


.matches('GetBySkillset', function(session,args){
	console.log('149');
var count=0;
var array = [];
LocArray =[];
var entity_skill = builder.EntityRecognizer.findEntity(args.entities, 'skillset');
if(entity_skill==null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(entity_skill.resolution);
//for(var j=0;j<entity_skill.resolution.values.length;j++){
			StoreSkill=entity_skill.resolution.values[0]
		//}
		console.log(StoreSkill)
//session.send('Can you add more filters to the data')
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].Skill.length;j++){
		//console.log(contents[i].Account[j]);
	if (tolower(contents[i].Skill[j])==tolower(StoreSkill)) {
		console.log('hello')
		array.push(contents[i].Location);
		count++;
	   //session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_skill.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		//session.send('output')
	}
	/*else
	{
		session.send('no such information found')
	}*/
}
}
array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                LocArray[j++] = array[i];  
            }  
         }  
        LocArray[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(LocArray)



if(count>1){
	console.log('More than 1')
	session.beginDialog('LocFilterOnSkill');
	
}
else if(count==1){
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].Skill.length;j++){
		//console.log(contents[i].Account[j]);
	if (tolower(contents[i].Skill[j])==tolower(StoreSkill)) {
		console.log('hello')
		//count++;
	   session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_skill.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		//session.send('output')
	}
	/*else
	{
		session.send('no such information found')
	}*/
}
}
session.beginDialog('getMessage');
}
else{
	 session.beginDialog('helpmenualt')
	    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}


}

})





/*.matches('GetBySkillset ', function(session,args){
	//console.log(contents);

var entity_skill = builder.EntityRecognizer.findEntity(args.entities, 'skillset');
console.log('153');
//session.send('Can you add more filters to the data')
for(var i=0; i<contents.length;i++){
	console.log('156');
	for(var j=0; j<contents[i].Skill.length;j++){
		//console.log(contents[i].Skill[j]);
	if (tolower(contents[i].Skill[j])==tolower(entity_skill.entity)) {
	   session.send('test')
	   // session.send('Here are the details of people who know \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_skill.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	}
	
}
}
})*/


.matches('subpractice_account', function(session,args){
 var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
 var entity_acc = builder.EntityRecognizer.findEntity(args.entities, 'account');
 var array = new Array();
 SkillArr=[];
if(entity_sub==null || entity_acc==null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

 
StoreSub=entity_sub
StoreAcc=entity_acc
console.log(entity_sub);
console.log(entity_acc);
var count = 0;
for(var j=0;j<entity_acc.resolution.values.length;j++){
			StoreAcc=entity_acc.resolution.values[j]
		}
		for(var j=0;j<entity_sub.resolution.values.length;j++){
			StoreSub=entity_sub.resolution.values[j]
		}
		console.log(StoreAcc)
			console.log(StoreSub)
	for(var i =0;i<contents.length;i++)
	{
		//session.send('Hi')

		for(var j=0;j<contents[i].Account.length;j++){
			for(var k=0;k<contents[i].SubPractice.length;k++){
		if(tolower(contents[i].SubPractice[k])==tolower(StoreSub) && tolower(contents[i].Account[j])==tolower(StoreAcc))
		{
			count++
			//SkillSet.push(contents[i].Skill);


				for(var j=0;j<contents[i].Skill.length;j++){
				
				//console.log(temp)
				if(contents[i].Skill[j]!=null || contents[i].Skill[j]!="")
			array.push(contents[i].Skill[j]);
			//SkillSet[k]=temp;
	}
	
			//session.send('Hi')
			//session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_acc.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		}
		/*else{
			session.send('no such information found')
		}*/
	}

}
	}
	
	array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     SkillArr.push('all')
console.log(SkillArr)
if (count>1){
		//session.endDialog('Please select the list of skills available \'%s\' from the \'%s\' sub practice, working with \'%s\' account.', SkillArr, StoreSub, StoreAcc);

	session.beginDialog('getSkillfilter');

}
else if(count==1){
	for(var i =0;i<contents.length;i++)
	{
		for(var j=0;j<contents[i].Account.length;j++){
			for(var k=0;k<contents[i].SubPractice.length;k++){
		if(tolower(contents[i].SubPractice[k])==tolower(StoreSub) && tolower(contents[i].Account[j])==tolower(StoreAcc))
		{
			session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreAcc,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		
		}
	}
}
}
session.beginDialog('getMessage');
}
else if(count==0){

   session.beginDialog('helpmenualt')
      console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}
})


.matches('Designation_sub_country', function(session,args){
 var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
  var entity_des = builder.EntityRecognizer.findEntity(args.entities, 'designation'); 
 var entity_cont = builder.EntityRecognizer.findEntity(args.entities, 'Country');

var array = new Array();
SkillArr=[];

if(entity_sub==null || entity_cont==null || entity_des==null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(entity_sub);
console.log(entity_cont);
console.log(entity_des.type)
console.log(entity_des.resolution.values);
console.log(entity_cont.resolution.values);

	
		for(var j=0;j<entity_des.resolution.values.length;j++){
			StoreDesignation=entity_des.resolution.values[j]
		}

for(var i=0;i<entity_cont.resolution.values.length;i++){
			StoreCountry=entity_cont.resolution.values[i]
		}
for(var k=0;k<entity_sub.resolution.values.length;k++){
			StoreSub=entity_sub.resolution.values[k]
		}


console.log(StoreDesignation)
console.log(StoreCountry)
var count=0;
for(var i =0;i<contents.length;i++)
	{
		for(var k =0;k<contents[i].SubPractice.length;k++){
		if(tolower(contents[i].SubPractice[k])==tolower(StoreSub) && tolower(contents[i].Country)==tolower(StoreCountry) && tolower(contents[i].Designation)==tolower(StoreDesignation))
		{
		count++;
		//SkillSet.push(contents[i].Skill);
			//session.send('Hi')
			//session.send('Here are the details of people working as \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_des.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
			//session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_acc.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	
	for(var j=0;j<contents[i].Skill.length;j++){
			
				//console.log(temp)
				if(contents[i].Skill[j]!=null || contents[i].Skill[j]!="")
			array.push(contents[i].Skill[j]);
			//SkillSet[k]=temp;
	}
	
}
	}	
	}

	array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     SkillArr.push('all')
console.log(SkillArr)
	if(count>1){
		//session.endDialog('Please select the list of skills available \'%s\' from the \'%s\' sub practice, designation \'%s\' in \'%s\' country.', SkillArr, StoreSub, StoreDesignation,StoreCountry);
		session.beginDialog('getSkillfordes');
	}
	else if(count==1){
		
		for(var i =0;i<contents.length;i++)
	{
	//	session.send('Hello')
		for(var k =0;k<contents[i].SubPractice.length;k++){
		if(tolower(contents[i].SubPractice[k])==tolower(StoreSub) && tolower(contents[i].Country)==tolower(StoreCountry) && tolower(contents[i].Designation)==tolower(StoreDesignation))
		{
		
			//session.send('Hi')
			//session.send('Here are the details of people working as \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_des.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
			session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreSub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	
	}
		}
	}
	session.beginDialog('getMessage');
	}
	else{
	    session.beginDialog('helpmenualt')
	       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
}
})


.matches('sub_location', function(session,args){
	var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
	 var entity_loc = builder.EntityRecognizer.findEntity(args.entities, 'location');
//console.log(entity_fname.entity);
var array= new Array()
SkillArr=[];


if(entity_sub==null || entity_loc==null){
	console.log(entity_sub)
		console.log(entity_loc)
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else {

			StoreSub=entity_sub.resolution.values[0]
		
		StoreLoc=entity_loc.resolution.values[0];
console.log(StoreLoc)
console.log(StoreSub)
var count=0;
var count1=0;
var count2=0;
var fname = new Array();
var lname = new Array();
for(var i=0; i<heads.length;i++){
	for(var j=0; j<heads[i].SubPractice.length;j++){
if(tolower(heads[i].SubPractice[j]) == tolower(StoreSub)){
	fname.push(heads[i].FirstName);
	lname.push(heads[i].LastName);
	}
}
}
for(var i=0; i<contents.length;i++){
	console.log('a')
	for(var m=0;m<fname.length;m++){
		console.log('b')
		for(var n=0;n<lname.length;n++){
			console.log('c')
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].Location)==tolower(StoreLoc)) {
		
		count++;
}
	for(var k=0;k<contents[i].SubPractice.length;k++){
		for(var j=0;j<contents[i].Skill.length;j++){

if(tolower(contents[i].SubPractice[k]) == tolower(StoreSub)){
				//console.log(temp)
				if(contents[i].Skill[j]!=null || contents[i].Skill[j]!="")
			array.push(contents[i].Skill[j]);
		console.log(array)
			console.log('arrayLoc')
			//SkillSet[k]=temp;
	}
}
}
}
}
}
array.sort();
	console.log('hello')
	//console.log(SkillSet)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
                console.log('Remove')
            }  
         }  
        SkillArr[j++] = array[array.length-1];      
     
console.log(SkillArr)
	if(count==0)
	{ 
for(var i=0;i<lookup.length;i++){
	for(var j=0;j<lookup[i].City.length;j++){
	if(tolower(lookup[i].City[j])==tolower(StoreLoc)){
StoreState=lookup[i].State;
	}
}
}
for(var i=0; i<contents.length;i++){
	for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].State)==tolower(StoreState)) {
		
		count1++;
}
}
}
} // session.beginDialog('helpmenualt')
	}
		else{
		for(var i=0; i<contents.length;i++){
				for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].Location)==tolower(StoreLoc)) {
		session.send('Here are the details of the head for \'%s\' in \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',StoreSub,StoreLoc,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)
	

	}
	}
}
}
session.beginDialog('AskForSkillOnHeadLocation');
}


if(count1==0){
for(var i=0;i<lookup.length;i++){
	if(tolower(lookup[i].State)==tolower(StoreState)){
StoreCountry=lookup[i].Country;
	}
}
for(var i=0; i<contents.length;i++){
	for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].Country)==tolower(StoreCountry)) {
		
		count2++;
}
}
}
} // session.beginDialog('helpmenualt')
	}
	else{
		for(var i=0; i<contents.length;i++){
				for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].State)==tolower(StoreState)) {
		session.send('I could not find the person in the location you mentioned. Here are the details of the head for \'%s\' in the state of \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',StoreSub,StoreState,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)
	

	}
	}
}
}
session.beginDialog('AskForSkillOnHeadState');
}
	
if(count2>0){
		for(var i=0; i<contents.length;i++){
				for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].Country)==tolower(StoreCountry)) {
		session.send('I could not find the person in the location you mentioned. Here are the details of the head for \'%s\' in the country \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',StoreSub,StoreCountry,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)
	
	}
	}
}
}
session.beginDialog('AskForSkillOnHeadOnCountry');
}
if(count==0&&count1==0&&count2==0){
for(var i=0; i<contents.length;i++){
				for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n])) {
		session.send('I could not find the person in the location you mentioned. Here are the details of the global head for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',StoreSub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)

	}
	}
}
}     
session.beginDialog('AskForSkillOnHeadDef');	
}
}
})



.matches('subcountry', function(session,args){
	var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
	 var entity_cont = builder.EntityRecognizer.findEntity(args.entities, 'Country');
//console.log(entity_fname.entity);
var array= new Array()
SkillArr=[];


if(entity_sub==null || entity_cont==null){
	console.log(entity_sub)
		console.log(entity_cont)
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

			StoreSub=entity_sub.resolution.values[0]
		
		StoreCountry=entity_cont.resolution.values[0];
console.log(StoreCountry)
console.log(StoreSub)
var count=0;
var fname = new Array();
var lname = new Array();
for(var i=0; i<heads.length;i++){
	for(var j=0; j<heads[i].SubPractice.length;j++){
if(tolower(heads[i].SubPractice[j]) == tolower(StoreSub)){
	fname.push(heads[i].FirstName);
	lname.push(heads[i].LastName);
	}
	/*else{
		session.send('There\'s no head for this sub practice.')
			session.beginDialog('getMessage');
	}*/
}
}


for(var i=0; i<contents.length;i++){
	for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].Country)==tolower(StoreCountry)) {
		
		count=1;

	}
	for(var k=0;k<contents[i].SubPractice.length;k++){
		for(var j=0;j<contents[i].Skill.length;j++){

if(tolower(contents[i].SubPractice[k]) == tolower(StoreSub) && tolower(contents[i].Country)==tolower(StoreCountry)){
				//console.log(temp)
				if(contents[i].Skill[j]!=null || contents[i].Skill[j]!="")
			array.push(contents[i].Skill[j]);
			console.log('array')
			//SkillSet[k]=temp;
	}
}
}
}
}
}
array.sort();
	console.log('hello')
	console.log(SkillSet)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
                console.log('Remove')
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(SkillArr)



	if(count==0)
	{     session.beginDialog('helpmenualt')
   console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}
	else{
		for(var i=0; i<contents.length;i++){
				for(var m=0;m<fname.length;m++){
		for(var n=0;n<lname.length;n++){
	if (tolower(contents[i].FirstName)==tolower(fname[m]) && tolower(contents[i].LastName)==tolower(lname[n]) && tolower(contents[i].Country)==tolower(StoreCountry)) {
		session.send('Here are the details of the head for \'%s\' in \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'  \n \n   Phone: \'%s\'.',StoreSub,StoreCountry,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email,contents[i].phone)
	

	}
	}
}
}
session.beginDialog('AskForSkillOnHeadCountry');
}
}
})

.matches('dataSc_location', function(session,args){
 var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
 var entity_loc = builder.EntityRecognizer.findEntity(args.entities, 'location');
var array = new Array()
var noduparray = new Array()
if(entity_sub==null||entity_loc==null){
	console.log('ss')
	 session.beginDialog('helpmenualt')
	    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(entity_sub.resolution);
console.log(entity_loc);
var count = 0;

var dataSc1;
var dataSc2;
var dataSc3;
			StoreLoc=entity_loc.resolution.values[0]
		
	
			dataSc1=entity_sub.resolution.values[0]
			dataSc2=entity_sub.resolution.values[1]
			dataSc3=entity_sub.resolution.values[2]
	console.log(dataSc1);
		console.log(dataSc2);
			console.log(dataSc3);
	for(var i =0;i<contents.length;i++)
	{
		for(var k=0;k<contents[i].SubPractice.length;k++){
		if(tolower(contents[i].SubPractice[k])==tolower(dataSc1) || tolower(contents[i].SubPractice[k])==tolower(dataSc2) || tolower(contents[i].SubPractice[k])==tolower(dataSc3))
			if(tolower(contents[i].Location)==tolower(StoreLoc)){
		{
			count++;
			array.push(contents[i].Email);
			console.log('array')
		
		}
	}
}	
}
array.sort();
	console.log('hello')
	//console.log(SkillSet)
	console.log('hi')
 var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                noduparray[j++] = array[i];  
                console.log('Remove')
            }  
         }  
        noduparray[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(noduparray)



if(count>0){
	for(var i =0;i<contents.length;i++)
	{
		for(var j=0;j<noduparray.length;j++)
		{
			if(contents[i].Email==noduparray[j])
		{
			session.send('Here are the details of people working as \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_sub.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		//session.beginDialog('getMessage');
		}
	}
}
session.beginDialog('getMessage');
}
else{
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}
})

.matches('getName', function(session,args){
 var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 var entity_acc = builder.EntityRecognizer.findEntity(args.entities, 'account');
console.log(entity_first);
console.log(entity_acc);
if(entity_first==null || entity_acc==null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
for(var i=0;i<entity_acc.resolution.values.length;i++){
			StoreAcc=entity_acc.resolution.values[i]
		}
	for(var i =0;i<contents.length;i++)
	{
		//session.send('Hi')
		for(var j=0; j<contents[i].Account.length;j++){
		if(tolower(contents[i].FirstName)==tolower(entity_first.entity) && tolower(contents[i].Account[j])==tolower(StoreAcc))
		{
			//session.send('Hi')
			session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreAcc,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	
		}
		/*else{
			session.send('no such information found')
		}*/
	}
	}	
	session.beginDialog('getMessage');
}
})

/*.matches('final_intent', function(session,args){
 var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
 var entity_des = builder.EntityRecognizer.findEntity(args.entities, 'designation');
  var entity_loc = builder.EntityRecognizer.findEntity(args.entities, 'location');
var count=0;
	for(var i =0;i<contents.length;i++)
	{
		session.send('Hi')
		
		if(tolower(contents[i].SubPractice)==tolower(entity_sub.entity) && tolower(contents[i].Designation)==tolower(entity_des.entity) && tolower(contents[i].Location)==tolower(entity_loc.entity))
		{
count++;

			//session.send('Here are the details of people working as \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_des.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
			session.send('Hello')
			
	}
		
}

if(count>0){
for(var i =0;i<contents.length;i++)
	{
		//session.send('Hi')
		
		if(tolower(contents[i].SubPractice)==tolower(entity_sub.entity) && tolower(contents[i].Designation)==tolower(entity_des.entity) && tolower(contents[i].Location)==tolower(entity_loc.entity))
		{

			session.send('Here are the details of people working as \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_des.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
			//session.send('Hi')
			//session.send('Hi')
		
		
	}
		
}
	session.beginDialog('getMessage');
}
else{
	session.send("No employee was found with the credentials you entered.")
	
		session.beginDialog('getMessage');
}
})*/

/*.matches('getDesignation', function(session,args){
	console.log(contents);

var entity_desg = builder.EntityRecognizer.findEntity(args.entities, 'designation');
console.log(entity_desg.entity);
var count=0;
for(var i=0; i<contents.length;i++){
	if (tolower(contents[i].Designation)==tolower(entity_desg.entity)) {
		session.send('\'%s\' \'%s\'',contents[i].FirstName,contents[i].LastName)
		//count=1;
	}
}
	
})*/


.matches('getDesignation', function(session,args,results,next){
	//console.log(contents);

var entity_des = builder.EntityRecognizer.findEntity(args.entities, 'designation');
if(entity_des==null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{
console.log(entity_des);
var count=0;

for(var i=0;i<entity_des.resolution.values.length;i++){
			StoreDesignation=entity_des.resolution.values[i]
		}
for(var i=0; i<contents.length;i++){
	//session.send('HI')
	if (tolower(contents[i].Designation)==tolower(StoreDesignation)) {
		count++;

	}
	console.log(count)
	
}

if(count>1)
	{
		session.beginDialog('getSub');	// begin a dialog: getSkill ** Navigate to Line: 173
	}
else if(count==1)
{
	for(var i=0; i<contents.length;i++){
	//session.send('HI')
	if (tolower(contents[i].Designation)==tolower(StoreDesignation)) {
		session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreSub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	}
	
	
}
session.beginDialog('getMessage')
}
else
{
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
}
}
)                


.matches('sub_division', function(session,args){
 var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
 var entity_div = builder.EntityRecognizer.findEntity(args.entities, 'division');
var array = new Array();
SkillArr=[];

if(entity_div==null || entity_sub == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

for(var i=0;i<entity_sub.resolution.values.length;i++){
			StoreSub=entity_sub.resolution.values[i]
		}
		for(var i=0;i<entity_div.resolution.values.length;i++){
			StoreDiv=entity_div.resolution.values[i]
		}
//StoreCountry=entity_cont
console.log(entity_sub);
console.log(entity_div.entity);
console.log('something')
var count = 0;
	for(var i =0;i<contents.length;i++)
	{
		//session.send('Hi')
		for(var k=0; k<contents[i].SubPractice.length;k++)
		{
		if(tolower(contents[i].SubPractice[k])==tolower(StoreSub) && tolower(contents[i].Division)==tolower(StoreDiv))
		{
		count++
		//SkillSet.push(contents[i].Skill);	
			for(var j=0;j<contents[i].Skill.length;j++){
			if(contents[i].Skill[j]!=null || contents[i].Skill[j]!="")
			array.push(contents[i].Skill[j]);
			//SkillSet[k]=temp;
	}
}
			//session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_sub.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		}
		/*else{
			session.send('no such information found')
		}*/
	}
	
	array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
	var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(SkillArr)
SkillArr.push('all')
	if(count>1){

	// session.endDialog('Please select the list of skills available \'%s\' from the \'%s\' sub practice in \'%s\' division.', SkillArr, StoreSub, StoreDiv);

		session.beginDialog('getSkillforsubdiv');
	
	}
	else if(count==1){

for(var i =0;i<contents.length;i++)
	{
		//session.send('Hi')
		for(var k=0; k<contents[i].SubPractice.length;k++)
		{
		if(tolower(contents[i].SubPractice[k])==tolower(StoreSub) && tolower(contents[i].Division)==tolower(StoreDiv))
		{
			
			session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreSub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
		}
		/*else{
			session.send('no such information found')
		}*/
	}
}
	session.beginDialog('getMessage');
	}
	else{

		    session.beginDialog('helpmenualt')
		       console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}	
}
})



.matches('GetBySubpractice', function(session,args){
	//console.log(contents);
var array = new Array();
var entity_sub = builder.EntityRecognizer.findEntity(args.entities, 'sub_practice');
if(entity_sub == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

console.log(entity_sub.entity);
StoreSub=entity_sub;
SkillArr=[];
var count=0;
for(var i=0;i<entity_sub.resolution.values.length;i++){
			StoreSub=entity_sub.resolution.values[i]
		}
//session.send('Can you add more filters to the data')
for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	for(var j=0; j<contents[i].SubPractice.length;j++){
	if (tolower(contents[i].SubPractice[j])==tolower(StoreSub)) {
	   // session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_account.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	//session.send('\'%s\' \'%s\' ',contents[i].FirstName,contents[i].LastName)
count++;
//SkillSet.push(contents[i].Skill);
	for(var k=0;k<contents[i].Skill.length;k++){
				
				if(contents[i].Skill[k]!=null || contents[i].Skill[k]!="")
			array.push(contents[i].Skill[k]);
			//SkillSet[k]=temp;
	}
	}
}
}

array.sort();
	console.log('hello')
	console.log(array)
	console.log('hi')
var j=0;
        for (var i=0; i<array.length-1; i++){ 
       
            if (array[i] != array[i+1]){  
                SkillArr[j++] = array[i];  
            }  
         }  
        SkillArr[j++] = array[array.length-1];     
        // Changing original array  
     
console.log(SkillArr)     
        // Changing original array  
     SkillArr.push('all')
//console.log(SkillArr)
if(count>1){

	 //session.endDialog('Please select the list of skills available \'%s\' from the \'%s\' sub practice.', SkillArr, StoreSub);
session.beginDialog('filterSkill');

}
else{
	for(var i=0; i<contents.length;i++){
	//console.log(contents[i].Account);
	if (tolower(contents[i].SubPractice)==tolower(StoreSub)) {
	   // session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',entity_account.entity,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	session.send('Here are the details of people working for \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',StoreSub,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	
	}
}
session.beginDialog('getMessage');
}
	/*else
	{
		session.send('no such information found')
	}*/
}
})


/*.matches('GetByLocation', function(session,args){
	//console.log(contents);

var entity_loc = builder.EntityRecognizer.findEntity(args.entities, 'location');
console.log(entity_loc.entity);
var count=0;
for(var i=0;i<entity_loc.resolution.values.length;i++){
			StoreLoc=entity_loc.resolution.values[i]
		}
console.log(StoreLoc)
for(var i=0; i<contents.length;i++){
	//session.send('HI')
	if(tolower(contents[i].Location)==tolower(StoreLoc)){
count++;

for(var j=0;j<contents[i].Skill.length;j++){
	SkillSet.push(contents[i].Skill[j])
	}
}

	
}
SkillSet.sort();
	console.log('hello')
	
	console.log('hi')

	console.log(SkillSet)
	console.log(count)
var j=0;
        for (var i=0; i<SkillSet.length-1; i++){ 
       
            if (SkillSet[i] != SkillSet[i+1]){  
                SkillArr[j++] = SkillSet[i];  
            }  
         }  
        SkillArr[j++] = SkillSet[SkillSet.length-1];     
        // Changing original array  
     
console.log(SkillArr)

if(count>1)
	{	
	 session.endDialog('Please select the list of skills available in \'%s\' from \'%s\'.', SkillArr, StoreLoc);
		session.beginDialog('getSkill');
		}	// begin a dialog: getSkill ** Navigate to Line: 173
else if(count==1){
	for(var i=0; i<contents.length;i++){
	//session.send('HI')
	if (tolower(contents[i].Location)==tolower(StoreLoc)) 
	{
		session.send('Here are the details of people working in \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',contents[i].Location,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	
	}

}
session.beginDialog('getMessage');
}
else{
		    session.send('We will reach back to you with the information that you are looking for.');
		session.beginDialog('getMessage');
	}	
}
)     */                               

.matches('GetByLocation', function(session,args,results,next){
	//console.log(contents);
SubPracticeArr = [];
SubPracticeArray = [];
var entity_loc = builder.EntityRecognizer.findEntity(args.entities, 'location');
if(entity_loc == null){
 session.beginDialog('helpmenualt')
    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
}
else{

console.log(entity_loc.entity);
var count=0;
for(var i=0;i<entity_loc.resolution.values.length;i++){
			StoreLoc=entity_loc.resolution.values[i]
		}
console.log(StoreLoc)
for(var i=0; i<contents.length;i++){
	//session.send('HI')
	if (tolower(contents[i].Location)==tolower(StoreLoc)) {
		count++;
//SkillSet.push(contents[i].Skill);
	//for(var j=0;j<contents[i].Skill.length;j++){
			for(var j=0; j<contents[i].SubPractice.length;j++)
			SubPracticeArr.push(contents[i].SubPractice[j]);
		
	

	}
	console.log(count)
	
}
	SubPracticeArr.sort();
	console.log('hello')
	console.log(SubPracticeArr)
	console.log('hi')

var j=0;
        for (var i=0; i<SubPracticeArr.length-1; i++){ 
       
            if (SubPracticeArr[i] != SubPracticeArr[i+1]){  
                SubPracticeArray[j++] = SubPracticeArr[i];  
            }  
         }  
        SubPracticeArray[j++] = SubPracticeArr[SubPracticeArr.length-1];     
        // Changing original array  
     
console.log(SubPracticeArray)

if(count>1)

	{
		
	session.beginDialog('subonloc');
		}	// begin a dialog: getSkill ** Navigate to Line: 173
else if(count==1){
	for(var i=0; i<contents.length;i++){
	//session.send('HI')
	if (tolower(contents[i].Location)==tolower(StoreLoc)) 
	{
		session.send('Here are the details of people working in \'%s\'  \n \n   Name: \'%s\' \'%s\'  \n \n   Position: \'%s\'  \n \n   Location: \'%s\'  \n \n   Practice: \'%s\'  \n \n   Email: \'%s\'.',contents[i].Location,contents[i].FirstName,contents[i].LastName,contents[i].Designation,contents[i].Location,contents[i].Practice,contents[i].Email)
	
	}

}
session.beginDialog('getMessage');
}
else{
	 session.beginDialog('helpmenualt')
	    console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
	}	
}
}
)                                    


.onDefault((session) => {
     session.beginDialog('helpmenualt')
   console.log(session.message.text)
var username = session.message.user.name;
var userid = session.message.address.user.id
var logger=[username,userid,session.message.text,date,'  \r\n  ']
     fs.appendFile("log.txt", logger, function(err) {
    if(err) {
        return console.log("There was an error.");
    }

    console.log("The file was saved!");
});
});





bot.dialog('getSkill',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'Please enter a skill (Enter "all" for all the records):')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResponse)
	GetValues(session,StoreResponse, StoreLoc);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])


//subonloc
bot.dialog('subonloc',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'There are multiple people who fit the criteria, please select a subpractice: ',SubPracticeArray)	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreSub= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	StoreSub=StoreSub.entity
	console.log(StoreSub)
	GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])
//SubFilterOnSkillLoc


bot.dialog('helpmenu',[function(session){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Try following sample queries: ',HelpArray,{listStyle : 4})	//Get skill from user


  session.endDialog();
}
	

])

bot.dialog('helpmenualt',[function(session){			// Start dialog: getSkill
	builder.Prompts.choice(session,'We will reach back to you with the information that you are looking for. In the mean while, you could try following sample queries: ',HelpArray)	//Get skill from user


   session.endDialog();
}

])



bot.dialog('AskForSkillOnHead',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Does this help? Are you looking for a particular skill set?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(SkillArr)
	StoreResponse=StoreResponse.entity
	console.log(StoreResponse)
	if(tolower(StoreResponse)=="yes"){
session.beginDialog('HeadSubSkill');
	}
	else{
		session.beginDialog('getMessage');
	}
	//GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])
//HeadSubSkill


bot.dialog('HeadSubSkill',[function(session,results){	
builder.Prompts.choice(session,' ', SkillArr);	
session.send(' Please enter a skill or serial number next to it.')	// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
},function(session,results){
	
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(StoreSub)
	GetValuesHeadSkillSub(session,StoreSkill.entity,StoreSub);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('AskForSkillOnHeadLocation',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Does this help? Are you looking for a particular skill set?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(SkillArr)
	StoreResponse=StoreResponse.entity
	console.log(StoreResponse)
	if(tolower(StoreResponse)=="yes"){
session.beginDialog('HeadSubSkillLocation');
	}
	else{
		session.beginDialog('getMessage');
	}
	//GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('HeadSubSkillLocation',[function(session,results){	
builder.Prompts.choice(session,'Please enter a skill:', SkillArr);		// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(StoreSub)
	GetValuesHeadSkillSubLocation(session,StoreSkill.entity,StoreSub);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])



bot.dialog('AskForSkillOnHeadState',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Does this help? Are you looking for a particular skill set?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(SkillArr)
	StoreResponse=StoreResponse.entity
	console.log(StoreResponse)
	if(tolower(StoreResponse)=="yes"){
session.beginDialog('HeadSubSkillState');
	}
	else{
		session.beginDialog('getMessage');
	}
	//GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('HeadSubSkillState',[function(session,results){	
builder.Prompts.choice(session,' Please enter a skill:', SkillArr);		// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(StoreSub)
	GetValuesHeadSkillSubState(session,StoreSkill.entity,StoreSub);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

bot.dialog('AskForSkillOnHeadDef',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Does this help? Are you looking for a particular skill set?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(SkillArr)
	StoreResponse=StoreResponse.entity
	console.log(StoreResponse)
	if(tolower(StoreResponse)=="yes"){
session.beginDialog('HeadSubSkillDef');
	}
	else{
		session.beginDialog('getMessage');
	}
	//GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('HeadSubSkillDef',[function(session,results){	
builder.Prompts.choice(session,' Please enter a skill:', SkillArr);		// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(StoreSub)
	GetValuesHeadSkillSubDef(session,StoreSkill.entity,StoreSub);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

bot.dialog('AskForSkillOnHeadOnCountry',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Does this help? Are you looking for a particular skill set?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(SkillArr)
	StoreResponse=StoreResponse.entity
	console.log(StoreResponse)
	if(tolower(StoreResponse)=="yes"){
session.beginDialog('HeadSubSkillOnCountry');
	}
	else{
		session.beginDialog('getMessage');
	}
	//GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('HeadSubSkillOnCountry',[function(session,results){	
builder.Prompts.choice(session,' Please enter a skill:', SkillArr);		// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(StoreSub)
	GetValuesHeadSkillSub(session,StoreSkill.entity,StoreSub);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('AskForSkillOnHeadCountry',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Does this help? Are you looking for a particular skill set?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//var entity_first = builder.EntityRecognizer.findEntity(args.entities, 'first_name');
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(SkillArr)
	StoreResponse=StoreResponse.entity
	console.log(StoreResponse)
	if(tolower(StoreResponse)=="yes"){
session.beginDialog('HeadSubSkillCountry');
	}
	else{
		session.beginDialog('getMessage');
	}
	//GetSubLoc(session,StoreSub, StoreLoc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('HeadSubSkillCountry',[function(session,results){	
builder.Prompts.choice(session,' Please enter a skill:', SkillArr);		// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(StoreSub)
	GetValuesHeadSkillSubCountry(session,StoreSkill.entity,StoreSub,StoreCountry);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

bot.dialog('SubFilterOnSkillLoc',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Please enter a subpractice or the serial number next to it:',SubPracticeArr)	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResponse)
	GetValuesForSubLocSkill(session,StoreResponse.entity, StoreLoc, StoreSkill);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('LocFilterOnAcc',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Please enter a Location or the serial number next to it.',LocArray)
	//session.send(LocArray)	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreLoc= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreLoc)
	GetValuesForLocAcc(session, StoreLoc.entity, StoreAcc);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])



bot.dialog('getSkillset',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'Please enter a skill (Enter "all" for all the records): ')	//Get skill from user
},function(session,results){
	//session.send('${SkillSet}')
	//session.send('k')
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResponse)
	GetValuesForSubCountry(session,StoreResponse, StoreCountry, StoreSub);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])

bot.dialog('getSkillfordes',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,' ',SkillArr)
	session.send('Please enter a skill or serial number next to it (Enter \'all\' to get all records.')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResponse)
	GetValuesForDesSubCountry(session,StoreResponse.entity, StoreCountry, StoreSub, StoreDesignation);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

//getskillforsubloc

bot.dialog('greetings', [
    function (session) {
        session.beginDialog('askName');
    },
    function (session, results) {
        session.endDialog(`Hello ${results.response}!`);
    }
]);



bot.dialog('getskillforsubloc',[function(session,results){	
builder.Prompts.choice(session,' ', SkillArr);		// Start dialog: getSkill
	//builder.Prompts.text(session,'')	//Get skill from user
session.send(' Please enter a skill or the serial number next to it.')	
},function(session,results){
	//session.send(`${results.response}`)
	//session.endDialogWithResult(results.response);
StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	
	console.log(StoreSkill.entity)
	console.log(Sub1)
	console.log(Loc1)
	GetValuesSkillSubLoc(session,StoreSkill.entity,Sub1,Loc1);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

bot.dialog('getSkillforsubdiv',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,' ',SkillArr)	//Get skill from user
	session.send('Please enter a skill or serial number next to it (Enter \'all\' to get all records.')
},function(session,results){
	//session.send(`${results.response}`)
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResponse)
	GetValuesForSubDiv(session,StoreResponse.entity, StoreDiv, StoreSub);	
	console.log(StoreDiv)
	console.log(StoreSub)								//Call function to handle file logic Line: 28
	//session.endDialog();
}
])



bot.dialog('getMessage',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Is there anything else I could help you with?',"yes|no")	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreResponse= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResponse)
	GetMessage(session,StoreResponse.entity);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])

bot.dialog('getDes',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'Please enter a designation:')	//Get skill from user
},function(session,results){
	

	//session.send(`${results.response}`)
StoreDesignation= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreDesignation)
	console.log(StoreResponse)


	GetValues1(session,StoreResponse, StoreLoc, StoreDesignation);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])

bot.dialog('filterSkill',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,' ',SkillArr)
	session.send('Please enter a skill or serial number next to it (Enter \'all\' to get all records.')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreSkill)
	GetValuesForSubSkill(session,StoreSub, StoreSkill.entity);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

bot.dialog('LocFilterOnSkill',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Please enter a Location or the serial number next to it.',LocArray)	//Get skill from user
},function(session,results){
	//console.log(results)
	//session.send(`${results.response}`)
 StoreLoc= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreLoc)
	GetValuesSkillLoc(session,StoreLoc.entity,StoreSkill);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])



bot.dialog('getSub',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'Please enter a subpractice:')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreResult= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResult)
	GetValuesForSubDes(session,StoreResult, StoreDesignation);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])


bot.dialog('getUsername',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'What is your name?')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
	var StoreName= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreName)
	session.send('Hi, \'%s\'. How may I assist you today? Type \'help\' for some sample queries',StoreName)									//Call function to handle file logic Line: 28
	session.endDialog();
}
])

bot.dialog('getLoc',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'Please enter a Location:')	//Get skill from user
},function(session,results){
	//console.log(results)
	//session.send(`${results.response}`)
 StoreResult2= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreResult2)
	GetValues3(session,StoreResult2,StoreDesignation,StoreResult);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])


bot.dialog('getLocation',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.text(session,'There are multiple people who fit the criteria provided by you. What Location are you looking for?')	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreCity= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreCity)
	SubCountryLoc(session,StoreSub, StoreCountry ,StoreCity);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])

bot.dialog('getSkillfilter',[function(session,results){			// Start dialog: getSkill
	builder.Prompts.choice(session,'Please enter a skill or serial number next to it (Enter \'all\' to get all records. ',SkillArr)	//Get skill from user
},function(session,results){
	//session.send(`${results.response}`)
 StoreSkill= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreSkill)
	SubAccSkill(session,StoreSub, StoreAcc ,StoreSkill.entity);									//Call function to handle file logic Line: 28
	//session.endDialog();
}
])

/*bot.dialog('getDes',[function(session,results){			
	builder.Prompts.text(session,'Please enter a designation:')	
},function(session,results){
	//session.send(`${results.response}`)
    StoreDesignation= results.response;						//{results.response} stores user response from builder.Prompt() 
	console.log(StoreDesignation)
	console.log('Get Des Test')
	GetValues1(session,StoreResponse, StoreLoc, StoreDesignation);									//Call function to handle file logic Line: 28
	session.endDialog();
}
])*/

bot.dialog('/', intents);




